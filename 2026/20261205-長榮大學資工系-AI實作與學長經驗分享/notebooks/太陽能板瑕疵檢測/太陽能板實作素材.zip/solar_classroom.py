"""Student notebook helpers. Official model code is kept unchanged in baseline/."""
from pathlib import Path
import hashlib
import html
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import venv
import zipfile

LABELS = {"solar_panel": "正常面板", "crack": "破裂", "hotspot": "熱點"}
OFFICIAL_URL = "https://www.aicup.tw/_files/archives/7fbdbf_18b591dc78024ea69c3e775c3e1f838c.zip?dn=aicup_tutorial+code.zip"
CDN_URL = "https://cc8cef99-6d17-4032-9a60-51a42f52d2e2.filesusr.com/archives/7fbdbf_18b591dc78024ea69c3e775c3e1f838c.zip?dn=aicup_tutorial+code.zip"


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


class SolarLab:
    def __init__(self, root, python=None, models=None):
        self.root = Path(root).resolve()
        self.base = self.root / "baseline"
        self.python = Path(python or os.environ.get("SOLAR_CLASSROOM_PYTHON") or
                           self.root / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python"))
        self.models = Path(models or os.environ.get("SOLAR_CLASSROOM_MODELS") or self.root / "models").resolve()
        self.cases = json.loads((self.root / "cases.json").read_text(encoding="utf-8"))
        self.results = self.root / "results"
        self.results.mkdir(exist_ok=True)
        self.device = None
        self.env = dict(os.environ, OMP_NUM_THREADS="4", MKL_NUM_THREADS="4", OPENBLAS_NUM_THREADS="4",
                        TOKENIZERS_PARALLELISM="false", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                        PYTHONIOENCODING="utf-8", PYTHONUTF8="1", MPLBACKEND="Agg",
                        MPLCONFIGDIR=str(self.root / ".matplotlib"))

    def _case(self, case_id):
        if case_id not in self.cases:
            raise ValueError("請選擇 case01～case10，例如 'case05'。")
        return self.results / case_id

    def _run(self, command, log, env=None):
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open("w", encoding="utf-8") as stream:
            result = subprocess.run([str(x) for x in command], cwd=self.base, env=env or self.env,
                                    stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode:
            tail = log.read_text(encoding="utf-8", errors="replace")[-6500:]
            raise RuntimeError(f"這個步驟沒有完成，請查看下方訊息或 {log.name}：\n{tail}")

    def setup_environment(self):
        """Use an isolated worker environment so Colab's notebook kernel need not restart."""
        if not self.python.exists():
            if sys.version_info[:2] not in ((3, 12), (3, 13)):
                raise RuntimeError("本教材使用 Python 3.12／3.13。請在 Colab 選用相容的執行階段後重試。")
            print("正在建立實作環境；第一次安裝套件需要幾分鐘。", flush=True)
            venv.EnvBuilder(with_pip=True).create(self.root / ".venv")

        probe = ("import json,importlib.metadata as m; names="
                 "['torch','torchvision','numpy','opencv-python','matplotlib','PyYAML','scipy',"
                 "'tqdm','pandas','seaborn','Pillow','requests','einops','transformers','tokenizers',"
                 "'safetensors','huggingface_hub','tensorboard','accelerate','peft']; print(json.dumps({n:m.version(n).split('+')[0] for n in names}))")
        checked = subprocess.run([str(self.python), "-c", probe], capture_output=True, text=True, env=self.env)
        needed = json.loads((self.root / "package_versions.json").read_text())
        try:
            ready = checked.returncode == 0 and json.loads(checked.stdout) == needed
        except ValueError:
            ready = False
        if not ready:
            print("安裝 PyTorch 與影像／語言模型套件……", flush=True)
            # CUDA 12.6 supports T4; Blackwell GPUs require CUDA 12.8 or newer.
            index = None
            if sys.platform.startswith("linux"):
                gpu = subprocess.run(["sh", "-c", "command -v nvidia-smi >/dev/null && nvidia-smi --query-gpu=compute_cap --format=csv,noheader"],
                                     capture_output=True, text=True)
                try:
                    cap = float(gpu.stdout.strip().splitlines()[0])
                    index = "cu128" if cap >= 10 else "cu126"
                except (ValueError, IndexError):
                    index = "cpu"
            cmd = [self.python, "-m", "pip", "install", "--disable-pip-version-check", "--no-cache-dir",
                   "torch==2.11.0", "torchvision==0.26.0"]
            if index:
                cmd += ["--index-url", "https://download.pytorch.org/whl/" + index]
            self._run(cmd, self.results / "install-torch.log")
            self._run([self.python, "-m", "pip", "install", "--disable-pip-version-check", "--no-cache-dir",
                       "-r", self.root / "requirements-inference.txt"], self.results / "install-packages.log")

        check = subprocess.run([str(self.python), str(self.root / "worker.py"), "environment"],
                               cwd=self.base, capture_output=True, text=True, env=self.env)
        if check.returncode:
            raise RuntimeError("套件檢查未通過：\n" + check.stderr[-4500:])
        info = json.loads(check.stdout)
        self.device = "0" if info["cuda"] else "cpu"
        (self.results / "environment.json").write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"環境就緒：Python {info['python']}，PyTorch {info['torch']}；使用 {info['device']}。", flush=True)
        if info.get("gpu_error"):
            print("GPU 測試未通過，這次改用 CPU：" + info["gpu_error"], flush=True)

    def prepare_models(self):
        """Download official ZIP once; extract only inference models and verify every file."""
        manifest = json.loads((self.root / "model_manifest.json").read_text(encoding="utf-8"))
        valid = lambda item: ((self.models / item["path"]).is_file() and
                              (self.models / item["path"]).stat().st_size == item["bytes"] and
                              sha256(self.models / item["path"]) == item["sha256"])
        missing = [item for item in manifest if not valid(item)]
        if missing:
            archive = self.root / ".official-models.zip"
            if not archive.exists() or not zipfile.is_zipfile(archive):
                print("從主辦方下載模型壓縮檔（約 952 MB），完成後會自動解壓。", flush=True)
                part = archive.with_suffix(".part")
                for url_index, url in enumerate((OFFICIAL_URL, CDN_URL)):
                    try:
                        request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                        with urllib.request.urlopen(request, timeout=120) as response, part.open("wb") as output:
                            total = int(response.headers.get("Content-Length") or 952220274)
                            done, last = 0, -1
                            for block in iter(lambda: response.read(4 * 1024 * 1024), b""):
                                output.write(block)
                                done += len(block)
                                progress = min(100, int(done / total * 10) * 10)
                                if progress != last:
                                    print(f"模型下載 {progress}%", flush=True)
                                    last = progress
                        if not zipfile.is_zipfile(part):
                            raise ValueError("下載內容不是完整 ZIP。")
                        part.replace(archive)
                        break
                    except Exception:
                        part.unlink(missing_ok=True)
                        if url_index == 1:
                            raise RuntimeError("模型下載中斷。請確認網路後重新執行這格；已驗證的模型檔會保留。")
            with zipfile.ZipFile(archive) as zipped:
                for item in missing:
                    dest = self.models / item["path"]
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    part = dest.with_name(dest.name + ".part")
                    with zipped.open(item["archive_path"]) as source, part.open("wb") as output:
                        shutil.copyfileobj(source, output, 4 * 1024 * 1024)
                    if sha256(part) != item["sha256"] or part.stat().st_size != item["bytes"]:
                        part.unlink(missing_ok=True)
                        raise RuntimeError(f"{dest.name} 的完整性檢查未通過，請重新執行。")
                    part.replace(dest)
            archive.unlink(missing_ok=True)
        print("官方模型已就緒：PRB-FPN 約 123 MB，Qwen 完整資料夾約 1,004 MB。", flush=True)

    def _worker_json(self, action, case_id):
        case_root = self._case(case_id)
        result = subprocess.run([str(self.python), str(self.root / "worker.py"), action,
                                 "--root", str(self.root), "--case", case_id],
                                cwd=self.base, env=self.env, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError(result.stderr[-4500:])
        return json.loads(result.stdout)

    def _show_image(self, action, case_id):
        from IPython.display import Image, display
        result = self._worker_json(action, case_id)
        display(Image(filename=result["image"], width=1200))

    def show_inputs(self, case_id):
        self._show_image("original", case_id)

    def _table(self, headers, rows):
        from IPython.display import HTML, display
        head = "".join(f"<th style='text-align:left;padding:8px 12px;border-bottom:2px solid #90a4b7'>{html.escape(str(h))}</th>" for h in headers)
        body = "".join("<tr>" + "".join(f"<td style='padding:8px 12px;border-bottom:1px solid #ccd5df;vertical-align:top;white-space:normal'>{html.escape(str(v))}</td>" for v in row) + "</tr>" for row in rows)
        display(HTML(f"<table style='border-collapse:collapse;max-width:1100px'><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"))

    def _pipeline(self, case_id, steps, threshold=0.25):
        area = self._case(case_id)
        work = area / "run"
        if self.device is None:
            raise RuntimeError("請先執行「準備執行環境」的程式區塊。")
        if not (self.models / "best.pt").exists():
            raise RuntimeError("請先執行模型下載的程式區塊。")
        for mod in ("EO", "IR"):
            dest = area / "test" / mod / "image" / f"{case_id}.jpg"
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(self.root / "cases" / case_id / f"{mod}.jpg", dest)
        (work / "sft_data").mkdir(parents=True, exist_ok=True)
        shutil.copy2(self.root / "candidates.json", work / "sft_data" / "candidates.json")
        if "dets" in steps:
            (work / "submission.json").unlink(missing_ok=True)
        command = [self.python, "-u", self.base / "pipeline.py", *steps,
                   "--reason-model", self.models / "qwen_reason", "--det-weights", self.models / "best.pt",
                   "--test-root", area / "test", "--work", work, "--device", self.device]
        if "dets" in steps:
            command += ["--conf", f"solar_panel={threshold},hotspot={threshold},crack={threshold}"]
        # --device only controls PRB; use the same CPU/GPU choice for Qwen's subprocess.
        env = dict(self.env)
        if self.device == "cpu":
            env["CUDA_VISIBLE_DEVICES"] = "-1"
        start = time.monotonic()
        self._run(command, area / ("-".join(steps) + ".log"), env)
        duration = time.monotonic() - start
        return duration

    def detect_with_prb(self, case_id):
        print(f"PRB-FPN 正在處理 {case_id} 的 EO、IR 影像……", flush=True)
        duration = self._pipeline(case_id, ["ir-norm", "detect", "dets"])
        print(f"偵測完成（{duration:.1f} 秒）。", flush=True)

    def show_detections(self, case_id):
        self._show_image("detected", case_id)
        dets = self._worker_json("detections", case_id)
        rows = [[mod] + [sum(o["label"] == label for o in dets[f"test/{mod}/image/{case_id}.jpg"]["objects"])
                          for label in LABELS] for mod in ("EO", "IR")]
        self._table(["影像", "正常面板", "破裂", "熱點"], rows)

    def show_prompt(self, case_id):
        from IPython.display import HTML, display
        prompts = self._worker_json("prompts", case_id)
        if not prompts:
            print("這次未偵測到破裂或熱點，沒有要交給 Qwen 的異常線索。")
            return
        selected = next((p for p in prompts if p["label"] == "hotspot"), prompts[0])
        display(HTML("<pre style='white-space:pre-wrap;padding:16px;border:1px solid #a8bed2;border-radius:8px;max-width:1000px'>"
                     + html.escape(selected["prompt"]) + "</pre>"))

    def explain_with_qwen(self, case_id):
        print("整理偵測線索，交給 Qwen 產生可能成因……", flush=True)
        duration = self._pipeline(case_id, ["submit"])
        print(f"成因步驟完成（{duration:.1f} 秒）。", flush=True)

    def show_reasons(self, case_id):
        result = self.read_result(case_id)
        rows = [["IR" if "/IR/" in key else "EO", LABELS[o["label"]], o["reason"]]
                for key, objects in result.items() for o in objects if o["label"] != "solar_panel"]
        if rows:
            self._table(["影像", "偵測結果", "Qwen 提出的可能成因"], rows)
        else:
            print("這次沒有偵測到破裂或熱點，因此沒有產生成因文字。請再對照原圖與人工標註。")

    def show_reference(self, case_id):
        self._show_image("reference", case_id)
        dets = self._worker_json("detections", case_id)
        gt = json.loads((self.root / "reference.json").read_text(encoding="utf-8"))
        rows = []
        for mod in ("EO", "IR"):
            key = f"test/{mod}/image/{case_id}.jpg"
            for label in LABELS:
                predicted = sum(o["label"] == label for o in dets[key]["objects"])
                expected = sum(o["label"] == label for o in gt[key]["objects"])
                rows.append([mod, LABELS[label], predicted, expected])
        self._table(["影像", "類別", "模型數量", "標註數量"], rows)
        ref_reasons = [[mod, LABELS[o["label"]], o["reason"]] for mod in ("EO", "IR")
                      for o in gt[f"test/{mod}/image/{case_id}.jpg"]["objects"] if o.get("reason")]
        if ref_reasons:
            self._table(["影像", "類別", "資料原有的參考成因"], ref_reasons)

    def read_result(self, case_id):
        path = self._case(case_id) / "run" / "submission.json"
        if not path.exists():
            raise RuntimeError("請先執行這個案例的 PRB-FPN 與 Qwen 步驟。")
        return json.loads(path.read_text(encoding="utf-8"))

    def download_result(self, case_id):
        result = self.read_result(case_id)
        target = self.results / f"{case_id}_練習結果.json"
        target.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            from google.colab import files
        except ImportError:
            from IPython.display import FileLink, display
            display(FileLink(str(target)))
        else:
            files.download(str(target))
        return target
