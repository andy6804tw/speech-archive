# AI CUP 2026 太陽能板瑕疵檢測與根因分析：官方 Baseline

這份 baseline 從無人機拍攝的一般影像（EO）與熱影像（IR）中，偵測太陽能板 `solar_panel`、熱點 `hotspot`、破裂 `crack` 的位置，
再為每個異常（`hotspot`、`crack`）寫一句中文成因說明（`reason`），最後輸出可以上傳 AIdea 的 `submission.json`。

```
                 ┌──────────────────────────── 定位（佔 70%）────────────────────────────┐
test IR ─► ir_gray.py（偽彩色→灰階）────┐
test EO ────────────────────────────────┴► PRB detect.py ─► yolo2dets.py ─► detections.json ─┐
                                                                                              ├─► infer_submission.py ─► submission.json
train 標註 ─► build_sft_data.py ─► train_sft.py ─► Qwen 0.5B (SFT) ───────────────────────────┘
                 └──────────────────────────── 成因文字（佔 30%）──────────────────────────┘
```

- **定位**：PRB-FPN（YOLOv7 架構）偵測器，附已訓練好的權重。
- **成因文字**：以訓練集標註微調（SFT）過的 Qwen2.5-0.5B-Instruct，附已微調好的權重。
- 官方 baseline 的分數以競賽頁公告為準。評分方式請看官方 evaluation kit 的 README。

---

## 0. 先看這裡

### 兩種用法

| 用法 | 做什麼 | 時間（RTX 5060 Ti 16 GB 實測） |
|---|---|---|
| **A. 重現官方 baseline**（第 3 節） | 用附的偵測器與 Qwen 權重直接產生提交檔，不訓練任何模型 | 約 3 分鐘 |
| **B. 自己訓練成因模型**（第 4 節） | 偵測器沿用附的權重；Qwen 從頭微調，再產生提交檔 | 約 50 分鐘（預設設定；改用 `--bs 8` 約 12 分鐘，見 4-5） |

第一次使用請先完成第 1、2 節，跑一次用法 A，確認環境沒問題、也看過完整的輸出，再進入用法 B 修改與訓練自己的版本。
偵測器也可以重新訓練，見第 5 節（選做）。

### 需要的環境

| 項目 | 需求 |
|---|---|
| 顯示卡 | NVIDIA GPU。用法 A 實測峰值約 2.6 GB（整張卡，含 Windows 桌面原本佔用的約 1 GB）。用法 B 依設定不同，見 4-5 的表 |
| 作業系統 | 官方在 Windows 11 驗證；Linux 也可使用，但未經官方驗證 |
| Python | **3.12**（官方只在 3.12 驗證；`requirements.txt` 固定的 scipy 1.18 需要 3.12 以上，numpy 2.2.6 不支援 3.14 以後的版本） |
| 硬碟空間 | 虛擬環境 `.venv` 約 5 GB（大部分是 torch）、程式與權重約 1.2 GB、資料約 1 GB；用法 A 的 `outputs/` 約 70 MB，用法 B 約 4 GB（訓練中途最多約 6.5 GB）。另外不論專案放在哪個磁碟，pip 下載快取（約 3 GB，可用 `pip cache purge` 清掉）與 Qwen 基底模型（約 1 GB）都會存在使用者資料夾（Windows 是 C 槽）。建議專案所在磁碟預留 15 GB、C 槽另外預留 5 GB（第 5 節重訓偵測器另需約 12 GB） |
| 網路 | 安裝套件需要。用法 B 第一次訓練會從 Hugging Face 下載 Qwen 基底模型（約 1 GB）；用法 A 不需要 |

官方驗證環境：Windows 11、RTX 5060 Ti 16 GB、Python 3.12.3（pip 已升級到 26.2.1）、torch 2.11.0（CUDA 12.8），其餘套件版本見 `requirements.txt`。
CUDA 12 版的 torch 需要夠新的 NVIDIA 驅動（RTX 50 系列需 570 版以上）；裝完後用 1-5 確認。

---

## 1. 安裝環境

以下指令都在**專案根目錄**（有 `pipeline.py` 的資料夾）執行。開終端機後先切換過去，例如 `cd D:\aicup_pv_baseline`（cmd 要換磁碟機時用 `cd /d D:\aicup_pv_baseline`）。

**專案請放在短路徑**，例如 `D:\aicup_pv_baseline`（整個路徑建議在 100 個字元以內）。Windows 有路徑長度 260 字元的限制，路徑太長時 1-3 安裝 torch 會失敗。
虛擬環境（1-2）建立後**不能搬移**：之後要把專案搬到別的資料夾，請刪掉 `.venv` 資料夾，再重做 1-2～1-5。

**1-1. 確認 Python 版本是 3.12**

```bash
python --version
```
應顯示 `Python 3.12.x`（Linux 請用 `python3.12 --version`）。
如果不是，請先安裝 Python 3.12：Windows 可到 python.org 下載 3.12 的安裝檔（建議 3.12.10，這是 3.12 最後一個有 Windows 安裝檔的版本），安裝程式第一頁請勾選「Add python.exe to PATH」，裝完把終端機關掉重開。
Linux（以 Ubuntu 24.04 為例）先安裝系統套件：`sudo apt-get install -y python3.12-venv python3-dev libgl1 libglib2.0-0`（`libgl1`、`libglib2.0-0` 是 opencv 需要的）。
Ubuntu 22.04 等沒有 `python3.12` 套件的系統，可以改用 conda／miniforge 或 uv 安裝 Python 3.12，這兩種都不需要 sudo：
conda 用 `conda create -n aicup python=3.12`、再 `conda activate aicup`，之後 1-2 的 `python3.12` 改成 `python`；
uv 用 `uv python install 3.12`，再用 `uv venv --seed --python 3.12 .venv` 取代 1-2 的第一行。
如果電腦上還有其他 Python 版本、`python --version` 仍不是 3.12，只要把 1-2 建立虛擬環境的那一行改成 `py -3.12 -m venv .venv` 即可。
虛擬環境啟用之後 `python` 就是 3.12，之後的指令都照寫 `python`，**不要**再用 `py -3.12`（它會跳過虛擬環境，改用沒裝套件的 Python）。

**1-2. 建立並啟用虛擬環境**（避免和電腦上其他專案的套件互相干擾）

Windows（PowerShell）：
```bash
python -m venv .venv
.venv\Scripts\Activate.ps1
```
Windows 的 PowerShell 預設不允許執行指令碼，第二行多半會出現「因為這個系統上已停用指令碼執行」。
請在同一個視窗先執行 `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`（只對目前這個視窗有效，不需要系統管理員權限），再執行 `.venv\Scripts\Activate.ps1`。之後每開一個新的 PowerShell 視窗，都要再執行一次這兩行。

Windows（命令提示字元 cmd）：
```bash
python -m venv .venv
.venv\Scripts\activate.bat
```
注意：`activate.bat` 在 PowerShell 裡執行不會報錯，但也不會啟用虛擬環境，一定要在 cmd 裡執行。

Linux：
```bash
python3.12 -m venv .venv
source .venv/bin/activate
```
啟用成功後，命令列前面會出現 `(.venv)`。**之後每次開新的終端機，都要先切到專案根目錄、重新啟用一次**，再執行後面的指令。

啟用之後，先把 pip 升級到最新版（Python 內附的 pip 可能比較舊）：
```bash
python -m pip install --upgrade pip
```

**1-3. 安裝 PyTorch**（依顯示卡選擇，要先裝這個）

| 顯示卡 | 指令 |
|---|---|
| RTX 50 / 40 / 30 系列、A100 等（官方驗證：RTX 5060 Ti） | `pip install torch==2.11.0 torchvision==0.26.0 --index-url https://download.pytorch.org/whl/cu128` |
| RTX 20、GTX 16／10 系列、MX、T4、V100 等較舊的卡（未經官方驗證） | `pip install torch==2.11.0 torchvision==0.26.0 --index-url https://download.pytorch.org/whl/cu126` |

RTX 50 系列一定要用第一列（cu128）；GTX 10 系列以前的卡一定要用第二列（cu126），cu128 版沒有這些卡的程式碼。

**1-4. 安裝其餘套件**

```bash
pip install -r requirements.txt
```

**1-5. 確認 GPU 可以使用**

```bash
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
```
應顯示 `2.11.0+cu128 True`（舊卡為 `+cu126`）。如果是 `False`，見第 7 節常見問題。
再實際在顯示卡上算一次，確認 torch 版本和顯示卡相配：
```bash
python -c "import torch; print(torch.ones(1, device='cuda') + 1)"
```
應顯示 `tensor([2.], device='cuda:0')`；出現 `no kernel image is available` 代表 1-3 選錯了版本。

---

## 2. 準備資料

需要三樣東西，請從競賽頁下載：

1. **訓練集**：解壓後的 `train/` 資料夾（裡面有 `EO/`、`IR/`，各自有 `image/` 與 `label/`）
2. **測試集**：解壓後的 `test/` 資料夾（裡面有 `EO/image/`、`IR/image/`）
3. **官方 evaluation kit**（`author-kit_1012.zip`）：裡面的 `make_submission.py`、`test_images.csv`、`sample_submission.json`

全部放進專案的 `data/` 資料夾，放好後應該長這樣：

```
data/
├── train/
│   ├── EO/image/*.jpg   EO/label/*.json     一般影像 1920x1080，labelme 標註（含 reason）
│   └── IR/image/*.jpg   IR/label/*.json     熱影像 640x512
├── test/
│   ├── EO/image/*.jpg
│   └── IR/image/*.jpg
├── make_submission.py       （evaluation kit）
├── test_images.csv          （evaluation kit）
└── sample_submission.json   （evaluation kit）
```

- **最常見的錯誤是資料夾多一層**：Windows 的「解壓縮全部」會先建一個以壓縮檔命名的資料夾，變成 `data\<壓縮檔名>\train\EO` 或 `data\train\train\EO`。
  請確認 `data\train`、`data\test` 底下**直接**就是 `EO`、`IR`。
- 訓練集壓縮檔裡也附有 `make_submission.py`、`sample_submission.json`，請使用 evaluation kit 的版本（兩個都放進 `data/` 時，讓 kit 的檔案覆寫掉）。

**檢查資料有沒有放對**（在專案根目錄執行）：

```bash
python -c "import os; [print(d, len(os.listdir(os.path.join('data', d))) if os.path.isdir(os.path.join('data', d)) else '找不到！請檢查資料夾是否多一層或放錯位置') for d in ['train/EO/image','train/EO/label','train/IR/image','train/IR/label','test/EO/image','test/IR/image']]"
```
應顯示 train 四個資料夾各 1046、test 兩個資料夾各 696。

資料放在別的地方也可以：之後每個 `python pipeline.py` 指令都加上 `--train-root <train 資料夾> --test-root <test 資料夾>`（兩個資料夾底下直接是 `EO`、`IR`）。
`make_submission.py` 不接受這兩個參數，不要加；evaluation kit 的三個檔案仍請放在 `data/`。

---

## 3. 快速開始：重現官方 baseline（用法 A）

```bash
python pipeline.py all --reason-model weights/qwen_reason
```

這一行會依序跑完第 4 節的步驟，但**不訓練任何模型**：偵測器用附的 `prb/runs/train/pv/weights/best.pt`，成因模型用附的 `weights/qwen_reason/`：

```
IR 偽彩色轉灰階 → 偵測 → 轉檔與後處理 → 建 SFT 資料（候選句）→ 驗證 → 產生 submission
```

跑完最後幾行會看到類似：

```
已寫入 ...\outputs\submission.json（1392 張影像、65185 個物件）
...
完成：ir-norm → detect → dets → sft-data → train-sft → eval → submit
```
（`train-sft` 這一步會顯示「不重訓，略過」。）

- 執行過程中會夾雜幾行英文警告，例如 `... incorrect regex pattern ... fix_mistral_regex=True`，是正常現象，**不需要修改程式**，說明見第 7 節。
- 中間驗證（eval）的結果會顯示「調和平均 0.000」，也是正常的，說明見 4-6。

然後檢查格式：

```bash
python data/make_submission.py --check outputs/submission.json
```

看到「格式檢查通過」就可以把 `outputs/submission.json` 上傳到 AIdea。

**想確認自己有沒有重現成功**：計算檔案的 SHA-256。PowerShell 用 `Get-FileHash outputs\submission.json`，cmd 用 `certutil -hashfile outputs\submission.json SHA256`，Linux 用 `sha256sum outputs/submission.json`。
官方 baseline 提交檔是 `7a45f309436cfbe2e3b53760ad799d85a866217afd14efe3809a6f664ab5096e`（英文大小寫不拘）。
在與官方相同的套件版本與顯卡下，兩者會完全相同。換顯卡、驅動或在 CPU 上執行時，浮點運算的差異可能讓少數框的座標或有無、以及少數 reason 句子不同，
這時雜湊值不同是正常的，分數也可能與官方略有差異；只要格式檢查通過就可以上傳。

**注意：`--reason-model` 只對這一次指令有效，不會被記住。** 還沒自己跑過 4-5（訓練 Qwen）之前，之後單獨執行 `eval` 或 `submit` 都要再加
`--reason-model weights/qwen_reason`，例如調完門檻後重出提交檔：

```bash
python pipeline.py dets submit --conf "solar_panel=0.3,hotspot=0.25,crack=0.25" --reason-model weights/qwen_reason
```

---

## 4. 自己訓練成因模型：一步一步做（用法 B）

`python pipeline.py <步驟>` 一次跑一個步驟，產出都放在 `outputs/`。下表是全部步驟，後面逐一說明：

| 步驟 | 指令 | 做什麼 | 產出 | 時間（實測） |
|---|---|---|---|---|
| 4-1 | `python pipeline.py ir-norm` | 測試集的偽彩色熱影像轉成灰階 | `outputs/test_IR_gray/` | 8 秒 |
| 4-2 | `python pipeline.py detect` | 偵測器跑測試集 EO、IR | `outputs/detect/` | 1.5 分鐘 |
| 4-3 | `python pipeline.py dets` | 偵測結果轉檔、依類別門檻過濾、後處理 | `outputs/detections.json` | 11 秒 |
| 4-4 | `python pipeline.py sft-data` | 訓練集標註轉成 Qwen 的訓練資料 | `outputs/sft_data/` | 1 秒 |
| 4-5 | `python pipeline.py train-sft` | 微調 Qwen | `outputs/qwen_reason/final/` | 46 分鐘（預設設定，見 4-5） |
| 4-6 | `python pipeline.py eval` | 在驗證集上看成因判斷準不準 | 只印在畫面上 | 11 秒 |
| 4-7 | `python pipeline.py submit` | 產生提交檔 | `outputs/submission.json` | 26 秒 |
| 4-8 | `python data/make_submission.py --check outputs/submission.json` | 檢查格式 | — | 幾秒 |

4-1 到 4-7 也可以一次跑完：`python pipeline.py all`。主要參數見 `python pipeline.py -h`；更細的參數見 `reason/`、`tools/` 各程式的 `-h`。

### 4-1. IR 偽彩色轉灰階

```bash
python pipeline.py ir-norm
```
訓練集的熱影像全是灰階（R=G=B），測試集的熱影像有一部分是偽彩色（用顏色表示溫度）。
偵測器只在灰階熱影像上學過熱點，直接拿彩色圖偵測，這些影像上幾乎偵測不到熱點。
`tools/ir_gray.py` 對每張影像各自處理：R、G、B 三個通道的平均差距大於 2 就當成彩色，用標準的亮度公式
（ITU-R BT.601：0.299 R + 0.587 G + 0.114 B，也就是 OpenCV 的 `cv2.COLOR_BGR2GRAY`）轉成灰階；本來就是灰階的影像原樣複製。
這是固定的公式，不從測試資料學任何參數、也不用任何標註。用亮度的理由是這份測試集的偽彩色是由暗到亮（暗紫、紅、橘、黃到白）的配色，越熱越亮；
彩虹（rainbow）那類配色就不適用這個公式。
換了測試影像（或改用別的 `--test-root`）之後，請從這一步重新跑起。
找不到可用的 ir-norm 輸出時，`detect` 會停下來提醒先跑這一步（測試集的熱影像全是灰階時才直接用原圖）。

### 4-2. 偵測

```bash
python pipeline.py detect
```
用附的偵測器權重 `prb/runs/train/pv/weights/best.pt`（PRB-FPN-CSP、輸入 1280）分別偵測 EO 與 IR。
先用很低的信心門檻 0.05 把所有候選框存下來，下一步再依類別過濾，所以**之後調門檻不用重跑這一步**（見 4-3）。
`detect` 跑完會在 `outputs/detect/_detect.json` 記錄這次用的權重、測試資料與 `--det-img`。之後只跑 `dets` 時會自動沿用當時的權重；
如果另外指定了不同的 `--det-weights`、`--det-img`，或測試資料不一樣，`dets` 會停下來要求從 `detect`（或 `ir-norm`）重跑。

多張顯示卡時，偵測步驟（`detect`、第 5 節的 `train-det`）只看 `--device`，例如 `--device 1` 用第 2 張卡；
Qwen 的步驟（`train-sft`、`eval`、`submit`）不看 `--device`，請用環境變數 `CUDA_VISIBLE_DEVICES` 指定（見 4-5）。
沒有 GPU 時偵測可以加 `--device cpu`（會非常慢）。

### 4-3. 轉檔、過濾與後處理

```bash
python pipeline.py dets --conf "solar_panel=0.25,hotspot=0.25,crack=0.25"
```
- `--conf` 是各類別的信心門檻（上面就是預設值）。評分**沒有信心分數、所有送出的框都計入分母**，所以門檻對定位分數影響很大。
  格式要照上面寫（類別名稱全小寫、逗號分隔），打錯會直接停下來說明；低於 0.05 的門檻沒有作用（4-2 只存 0.05 以上的框）；
  `--conf` 只在 `dets` 這一步生效。
- **改了門檻之後，要再跑 4-7 才會更新提交檔**（只跑這一步只會更新 `outputs/detections.json`）：
  `python pipeline.py dets submit --conf "..."`；還沒自己訓練 Qwen 的話再加 `--reason-model weights/qwen_reason`。
- 依訓練集標註統計做後處理：熱點只出現在 IR（444/444）、破裂只出現在 EO（352/352），不可能的類別直接拿掉；
  異常的標註框直接取代該片面板（訓練集中兩者幾乎不重疊：IoU≥0.5 只有 1/796），所以異常框位置上的 `solar_panel` 框會刪掉。

### 4-4. 建立 Qwen 的訓練資料

```bash
python pipeline.py sft-data
```
每個有 `reason` 的熱點／破裂標註會變成一筆對話，例如：

```
[system] 你是太陽能電廠的無人機巡檢工程師……用一句繁體中文說明該瑕疵最可能的成因。
[user]   影像類型：熱影像(IR)，640x512
         待說明瑕疵：熱點(hotspot)
         瑕疵位置：中心(84%, 46%)，寬佔 25.5%、高佔 49.2%，長寬比 1.5
         瑕疵面積約為單片面板的 1.65 倍，與 0 片面板重疊
         同一張影像：面板 7 片、hotspot 1 個、crack 0 個
         同編號可見光(EO)影像：面板 4 片、hotspot 0 個、crack 1 個；異常位置 crack(73%, 49%)
         請說明此瑕疵的可能成因。
[assistant] 推測破裂處導電路徑受損，電阻升高而累積熱量造成熱點。
```
- 依影像編號隨機切 15% 當驗證集（`--val-ratio`；同編號的 EO 與 IR 一定在同一邊）。
  注意：這樣的切法沒有依資料集補充檔的 `train_groups.csv` 分組。同一個 group 的影格來自同一段連續拍攝、畫面很像，
  所以驗證集的影格在訓練集裡幾乎都有相似的影格，驗證數字會偏樂觀。官方 evaluation kit 第 10.3 節建議以 group 為單位切分；
  但訓練集只有少數 group 含熱點／破裂，依 group 切分時要注意驗證集或訓練集可能完全缺少某些成因。
- 訓練資料會做框座標抖動、隨機漏掉少數面板，模擬測試時用的是偵測框而不是標註框。
- 以 `approx_group()` 近似出的少數成因群組（本地分法，不是官方分類，見 4-6）會過採樣到約 150 筆
  （由 `reason/build_sft_data.py` 的 `--min-group` 控制，`pipeline.py` 沒有這個參數）。
- `outputs/sft_data/candidates.json` 是整個訓練集（包含切出來當驗證集的 15%）出現過的所有 reason 句子，4-7 會用到；
  因為也包含驗證集的句子，4-6 的 `snap`／`rank` 結果會略偏樂觀。

### 4-5. 微調 Qwen

```bash
python pipeline.py train-sft
```
- **第一次執行會從 Hugging Face 下載 `Qwen/Qwen2.5-0.5B-Instruct`（約 1 GB）**，固定在版本 `7ae557604adf67be50417f59c2c2f167def9a775`，確保大家用的是同一個基底模型。
- 預設：全參數微調、4 個 epoch（`--epochs`）、學習率 2e-5、batch 16（`--bs`），只對回答的部分算 loss；每個 epoch 結束用驗證集 loss 選最好的一版。
- 訓練中途 `outputs/qwen_reason/` 最多會同時有兩份 checkpoint（每份約 2.8 GB）；訓練完之後的步驟只用 `final/`，`checkpoint-*` 可以刪掉。
- 開始訓練前會先刪掉舊的 `outputs/qwen_reason/final/`，訓練完成才寫入新的 `final/` 與 `train_args.json`（訓練參數紀錄），所以中途中斷不會留下舊模型。
  **用 `--epochs 0.2` 試跑也會覆寫 `final/`**：之後的 `eval`、`submit` 沒加 `--reason-model` 時就會用到這個試跑模型（程式會印出「成因模型：…」和提醒）。
- **顯示記憶體與速度**（RTX 5060 Ti 16 GB 實測，每種設定試跑約 0.12 個 epoch）：「配置峰值」是張量實際用到的量，「保留峰值」另外包含 PyTorch 的快取，不全是必要的用量；實際需要的量介於兩欄之間。實測 `--lora`（batch 16）的保留峰值 24.8 GB 超過卡的容量，速度仍然正常；配置峰值也超過卡的容量的預設 batch 16 才明顯變慢。下面的選卡建議是依此推估：

  | 設定 | 配置峰值 | 保留峰值 | 訓練速度 | 4 個 epoch 約需 |
  |---|---|---|---|---|
  | 預設（batch 16） | 16.2 GB | 25.9 GB | 每秒 3.3 筆 | 46 分鐘（完整跑過） |
  | `--bs 8` | 9.5 GB | 15.7 GB | 每秒 19.9 筆 | 8 分鐘 |
  | `--bs 4` | 6.2 GB | 11.2 GB | 每秒 17.7 筆 | 9 分鐘 |
  | `--lora`（batch 16） | 15.8 GB | 24.8 GB | 每秒 16.9 筆 | 9 分鐘 |
  | `--lora --bs 8` | 8.4 GB | 16.5 GB | 每秒 21.5 筆 | 7 分鐘 |
  | `--lora --bs 4` | 4.8 GB | 8.8 GB | 每秒 16.9 筆 | 9 分鐘 |

  - 預設的 batch 16 在 16 GB 的卡上放不下（配置峰值就超過 16 GB）：Windows 會借用系統記憶體繼續跑，所以特別慢；Linux 沒有這個機制，會直接出現 out of memory，請改用 `--bs 8`。
  - 主要用量來自模型的輸出層：batch 16、8 時 `--lora` 幾乎不省顯示記憶體，batch 4 時才省下約 2 GB（保留峰值 11.2 → 8.8 GB）；**要省記憶體主要靠調小 `--bs`**。
  - 建議：16 GB 的卡用 `--bs 8`；12 GB 的卡用 `--bs 4`；8 GB 的卡試 `--lora --bs 4`（依上表推估，未經官方在這些卡上驗證）。正式訓練前可以先加 `--epochs 0.2` 試跑幾分鐘，確認不會 out of memory，而且速度沒有比上表慢很多（Windows 上顯示記憶體不夠時通常不會出現 out of memory，而是速度明顯變慢）。
  - **改了 `--bs`、`--lora` 等設定，訓練出的模型會和官方 baseline 不同，分數也會不同。**
- 精度：RTX 30 系列以後的卡自動用 bf16；V100、T4 等較舊的卡自動改用 fp16 混合精度，若 loss 出現 `nan` 請加 `--precision fp32`。
  上表都是 bf16 的實測。RTX 20、GTX 16／10、V100、T4 等較舊的卡用 fp16 混合精度時權重是 fp32，顯示記憶體比上表多約 2～4.5 GB、
  checkpoint 與 `final/` 也大一倍，請把 `--bs` 再調小一級並先試跑；這些卡在用法 A 推論時 Qwen 也用 fp32，整張卡約需 4 GB。
- 換別的語言模型：`--llm <Hugging Face 模型名稱>`（版本可用 `--llm-revision` 指定）。
- 多張顯示卡時，用環境變數指定 Qwen 用哪一張：PowerShell `$env:CUDA_VISIBLE_DEVICES="1"`，cmd `set CUDA_VISIBLE_DEVICES=1`，Linux `CUDA_VISIBLE_DEVICES=1 python pipeline.py train-sft`。
  不指定而且看得到多張卡時，訓練會同時用上所有卡，實際 batch 會變成 `--bs` × 卡數，結果與官方 baseline 不同。
- GPU 上的訓練不是逐位元可重現，即使設定完全相同，每次重新訓練的結果也會有些微差異；要和官方 baseline 完全一致，請用附的權重（用法 A）。

### 4-6. 驗證

```bash
python pipeline.py eval
```
在 4-4 切出的驗證集（133 筆）上，印出兩組結果：
1. **純規則 baseline**：只看「同編號另一模態有沒有異常」，選訓練集中該情境最常見的成因與句子；
2. **你的 Qwen 模型**。

每組都會列出各成因群組的準確率（`group acc`）與各群組答對幾筆，以及「各群組 recall 的調和平均」。
成因群組是用 `reason/common.py` 的 `approx_group()` 關鍵字規則近似出來的，**不是官方分類**；這個調和平均也**不是官方分數**。
驗證集只有 133 筆、又沒有依 group 切分（見 4-4），數字有雜訊而且偏樂觀，只能當作參考。

**參考數字**（附的權重，用法 A 會印出同樣的結果）：

| | group acc | 旁路二極體或電池串 | 電池片裂紋 | 表層局部破損 | 調和平均 |
|---|---|---|---|---|---|
| 純規則 baseline | 0.895 | 0/7 | 0/3 | 6/9 | 0.000 |
| 附的 Qwen | 0.902 | 6/7 | 3/3 | 0/9 | 0.000 |

只要有一個群組全錯，調和平均就是 0，而少數群組在驗證集只有 3～9 筆，所以 **0.000 不代表程式或訓練壞掉**，請看各群組的結果。
`approx_group()` 只看關鍵字，少數句子會被分錯：例如「該片模組的板體破裂，損傷不僅止於表面。」「模組板出現裂損，並非單純表層刮傷。」
會被分到「表層局部破損」，驗證集的 9 筆「表層局部破損」裡就有 4 筆是這種句子，這一群的數字請保留解讀。
自己重新訓練的結果每次會略有不同（官方某次重訓為 group acc 0.850，調和平均同樣是 0.000）。

### 4-7. 產生提交檔

```bash
python pipeline.py submit
```
讀取 4-3 的偵測結果，為每個異常框產生 reason，寫出 `outputs/submission.json`。產生 reason 有三種方式（`--mode`）：
- `snap`（預設）：Qwen 先生成一句，再對齊到訓練集出現過最相近的句子；
- `rank`：不生成，直接在候選句中挑 Qwen 認為機率最高的一句；
- `generate`：直接使用 Qwen 生成的句子。

最後會列出各類別最常出現的 reason。**如果某一類幾乎全是同一句，代表模型退化成只會說一句話。**

生成時不抽樣（greedy），但會沿用模型 `generation_config.json` 裡的 `repetition_penalty 1.1`。
`snap`／`generate` 是一批一批生成的，同一批的其他句子會些微影響結果：改了 `--conf` 之後，即使某個框和它的題目都沒變，reason 也可能不同（`rank` 不受影響）。

這一步也會做簡易的格式自我檢查，但只涵蓋部分規則（例如不檢查 BOM、檔案大小、key 是否在 `test_images.csv` 中），
發現問題時只會印出「格式檢查失敗」、檔案仍會寫出，所以**不能取代 4-8 的官方檢查**。

### 4-8. 檢查格式並上傳

```bash
python data/make_submission.py --check outputs/submission.json
```
看到「格式檢查通過」就可以上傳。上傳規則與每日次數以競賽頁為準。

### 最終版的建議做法

先保留驗證集調好參數，最後把驗證集也拿去訓練，再產生要上傳的檔案。**調參時在 `train-sft`／`submit` 用過的參數都要原樣加上**
（例如 `--bs`、`--lora`、`--epochs`、`--lr`、`--llm`、`--mode`），沒加的會回到預設值：

```bash
python pipeline.py sft-data train-sft submit --val-ratio 0 <調參時用的參數>
# 例如調參時用了 --bs 8：
python pipeline.py sft-data train-sft submit --val-ratio 0 --bs 8
# 也調過門檻的話，要加上 dets（--conf 只在 dets 生效）：
python pipeline.py dets sft-data train-sft submit --val-ratio 0 --bs 8 --conf "solar_panel=0.3,hotspot=0.25,crack=0.25"
```
- 沒有驗證集時不會挑選最佳 epoch，直接使用最後一個 epoch 的模型；`eval` 步驟也會略過。
- 這個指令會覆寫 `outputs/qwen_reason/` 和 `outputs/submission.json`，想保留先前的提交檔請先另存一份。
- 它也會把 `outputs/sft_data/` 改成沒有驗證集的版本；之後還要再調參，請先重跑 `python pipeline.py sft-data`。
- 跑完同樣要執行 4-8 的格式檢查再上傳。

---

## 5. （選做）重新訓練偵測器

附的偵測器已經訓練好，一般不需要重訓。如果想改偵測器：

```bash
python pipeline.py yolo-data
python pipeline.py train-det --det-batch 4
```
- `yolo-data` 把訓練集的 labelme 標註轉成 YOLO 格式（`outputs/yolo_ds/`，隨機 10% 影像編號當驗證集；
  同樣沒有依 `train_groups.csv` 分組，驗證集的 mAP 會偏高，見 4-4 的說明）。重跑時會先清掉舊的 `yolo_ds`。
  這個切分和附的偵測器當初訓練時的切分不同，所以 `yolo_ds` 的驗證集大多是附的偵測器訓練過的影像。
  `yolo_ds` 裡的影像是 `data/train` 的硬連結（同一份檔案），不要直接修改 `yolo_ds` 裡的影像。
- `train-det` 從預訓練權重 `prb/yolo7.pt` 開始訓練 200 個 epoch（`--det-epochs`），輸入 1280。
  附的權重原本是在大記憶體的伺服器上以 batch 8 訓練（約需 30 GB 顯示記憶體）；16 GB 的卡請把 `--det-batch` 調小。
  實測 RTX 5060 Ti 16 GB 用 `--det-batch 4` 可以跑（顯示記憶體峰值約 15 GB），一個 epoch 約 6 分鐘，200 個 epoch 約需 19 小時；想先試跑可以加 `--det-epochs 10` 之類減少 epoch 數。
- 新權重在 `outputs/det_train/pv/weights/best.pt`。要改用它，**必須從 `detect` 重跑**（只跑 `dets` 會沿用舊偵測器的框，程式會停下來提醒）：
  ```bash
  python pipeline.py detect dets submit --det-weights outputs/det_train/pv/weights/best.pt --reason-model weights/qwen_reason
  ```
  （已經自己訓練過 Qwen 的話，不用加 `--reason-model`。）之後只跑 `dets submit --conf ...` 調門檻時，會自動沿用 `detect` 當時用的這個權重，不用再加 `--det-weights`。
- 重跑 `train-det` 會寫到同一個 `outputs/det_train/pv/`，覆蓋上一次的 `best.pt`；想保留請先把資料夾改名。
- 硬碟空間：`outputs/yolo_ds/` 約 0.5 GB。`train-det` 還會在 `weights/` 存 `init.pt`（約 0.25 GB），並在第 0 個 epoch、每 25 個 epoch、最後 5 個 epoch 各存一份含優化器狀態的 `epoch_*.pt`（每份約 0.74 GB）；訓練中的 `last.pt`、`best.pt` 也各約 0.74 GB，結束時才縮成約 0.12 GB。200 個 epoch 共存 13 份 `epoch_*.pt`，最多約需 11.5 GB；`--det-epochs 10` 試跑也會存 6 份，最多約 6 GB。之後的步驟只用 `best.pt`，訓練完 `init.pt` 與 `epoch_*.pt` 可以刪掉。
- 改了 `--det-batch` 等設定，訓練出的偵測器會和附的權重不同；即使設定完全相同，GPU 上重訓的結果每次也會有些微差異。

---

## 6. 想改進 baseline？

一些可以嘗試的方向：

- **調整各類別的信心門檻（`--conf`）**：定位佔總分 70%，而且所有送出的框都計入分母。改完用 `python pipeline.py dets submit --conf "..."` 重出提交檔（見 4-3）。
  注意：附的偵測器是用訓練集訓練的，直接在訓練集上評估會偏樂觀。baseline 沒有附在驗證集上計算官方分數的程式；
  第 5 節 `train-det` 跑完後，`outputs/det_train/pv/` 裡的 YOLO 驗證指標（例如 `F1_curve.png`）可以粗略參考，但它與官方評分方式不同。
  要精確比較，需依 evaluation kit README 的評分規則自行撰寫評分程式；切驗證集時建議依 `train_groups.csv` 以 group 為單位切分。
- **改成因模型**：換更大的語言模型（`--llm`）、用 LoRA（`--lora`）、或修改 prompt。prompt 由 `reason/common.py` 的 `describe()` 產生，訓練與推論共用同一個函式，改的時候兩邊會一起變。
- **加入影像資訊**：baseline 的成因模型只看偵測框的位置與數量，沒有看影像本身。
- 評分方式（配對規則、文字分數怎麼算）請詳讀官方 evaluation kit 的 README，再決定要優化哪一部分。

---

## 7. 常見問題

**`torch.cuda.is_available()` 是 `False`**
可能是忘了啟用虛擬環境、裝到 CPU 版的 torch，或顯示卡驅動太舊。先確認命令列前面有 `(.venv)`；再依 1-3 的表格重新安裝 torch（先 `pip uninstall torch torchvision`），並更新 NVIDIA 驅動。

**出現 `no kernel image is available` 之類的錯誤**
torch 版本和顯示卡不相配：RTX 50 系列要 cu128（1-3 表格第一列），GTX 10 系列以前的卡要 cu126（第二列）。先 `pip uninstall torch torchvision`，再用正確的指令重新安裝。

**安裝 torch 時出現 `OSError: [Errno 2] No such file or directory`（路徑裡有 `.venv\Lib\site-packages\torch\include`），或執行時出現 `DLL load failed`**
專案路徑太長（Windows 路徑上限 260 字元）。把專案搬到短路徑（例如 `D:\aicup_pv_baseline`），刪掉 `.venv` 資料夾，再重做 1-2～1-5（虛擬環境不能搬移）。

**Linux 出現 `ImportError: libGL.so.1`**
缺少 opencv 需要的系統函式庫：`sudo apt-get install -y libgl1 libglib2.0-0`。沒有 sudo 權限時，改裝不需要這些函式庫的版本：
`pip uninstall -y opencv-python`，再 `pip install opencv-python-headless==5.0.0.93`。

**`ModuleNotFoundError: No module named 'einops'`（或其他套件）**
沒有在虛擬環境裡安裝套件，或忘了啟用虛擬環境。啟用後重新執行 `pip install -r requirements.txt`。
如果指令是用 `py -3.12 ...` 執行的，請改成 `python ...`（`py -3.12` 不會使用虛擬環境）。

**執行 `eval` 或 `submit` 出現「找不到成因模型 ...qwen_reason\final」**
還沒自己訓練 Qwen（4-5）。請在指令後面加 `--reason-model weights/qwen_reason` 改用附的權重，或先跑 `python pipeline.py train-sft`。

**訓練 Qwen 時顯示記憶體不足（CUDA out of memory），或訓練非常慢**
調小 `--bs`（16 GB 卡用 8、12 GB 卡用 4，8 GB 卡試 `--lora --bs 4`）；batch 大時 `--lora` 幾乎不省顯示記憶體，batch 4 時才省約 2 GB。見 4-5 的表。

**訓練 Qwen 時無法下載模型**
需要能連到 huggingface.co。下載過一次之後會存在本機快取，之後若要離線執行，請先在同一個終端機視窗設定環境變數，再執行指令：
PowerShell `$env:HF_HUB_OFFLINE="1"`，cmd `set HF_HUB_OFFLINE=1`，Linux `HF_HUB_OFFLINE=1 python pipeline.py train-sft`。

**Windows 出現「系統找不到指定的路徑」（`FileNotFoundError: [WinError 3]`）**
最常見的原因是資料夾多了一層或放錯位置。找不到的路徑印在 `FileNotFoundError: [WinError 3] 系統找不到指定的路徑。:` 那一行的結尾（例如 `...\data\train\EO\label`），不是整段訊息的最後一行；最後一行的 `subprocess.CalledProcessError ... returned non-zero exit status 1.` 只表示該步驟失敗。請用第 2 節的檢查指令確認。
資料位置正確仍出現的話，可能是 Windows 路徑長度上限 260 字元，請把專案放在短路徑，例如 `D:\aicup_pv_baseline`；搬移後要刪掉 `.venv` 重做 1-2～1-5。
`eval`、`submit` 前面沒跑過 `sft-data`、`dets` 時，程式會直接說明缺少哪一步。

**執行時出現英文警告（warning），要處理嗎？**
不用。以下訊息在官方驗證環境中每次都會出現，不影響結果（用法 A 照樣產生與官方完全相同的提交檔），**請不要為此修改程式**：
- `The tokenizer you are loading from '...' with an incorrect regex pattern ... You should set the fix_mistral_regex=True flag`（eval、submit）：transformers 4.57 對本機模型資料夾的誤報。
- `The following generation flags are not valid and may be ignored: ['temperature', 'top_p', 'top_k']`（eval、submit）：baseline 產生 reason 時不抽樣，用不到這些參數。
- `UserWarning: torch.meshgrid: in an upcoming release ...`（detect）。
- `There were missing keys in the checkpoint model loaded: ['lm_head.weight']`（train-sft 結束時）：Qwen 的輸出層與詞嵌入共用同一份權重，存檔時本來就不另外存。
- 第一次訓練下載 Qwen 時，Windows 可能出現 huggingface_hub 關於 symlinks 的提示（建議開啟開發人員模式）：只是快取比較佔空間，不影響結果。

**畫面上的中文變成亂碼，或出現 `UnicodeEncodeError`**
先設定環境變數再執行：PowerShell 用 `$env:PYTHONUTF8="1"`，cmd 用 `set PYTHONUTF8=1`。

**detect 出現「一個框都沒有偵測到」**
先確認 `--det-weights` 與 `--test-root`；只訓練很少 epoch 的試跑偵測器也可能還偵測不到任何框。較舊的顯示卡若是半精度（fp16）運算出錯，可以在 detect 加 `--device cpu`（會很慢）。

**從舊版 baseline 更新，或把專案搬到別的資料夾之後**
`outputs/` 裡的舊結果不能再用：請刪掉 `outputs/`，或從頭跑 `python pipeline.py all --reason-model weights/qwen_reason`（至少要從 `ir-norm` 開始重跑）。
只跑後面的步驟時，程式會發現舊結果和現在的設定對不上而停下來說明。

**`outputs/` 會被覆寫嗎？**
會，每次執行都會覆寫同名檔案。想保留舊結果，請先把檔案另存，或在**整個流程**都加上 `--work <其他資料夾>`（`--work` 指定的資料夾裡要有之前步驟的產出，後面的步驟才找得到）。

**重新訓練後的結果和官方 baseline 不完全一樣**
正常。用附的偵測器權重時，偵測結果在相同環境下每次都相同；但重新訓練偵測器（第 5 節）與 Qwen 在 GPU 上的訓練都不是逐位元可重現，16 GB 的卡重訓偵測器還要把 `--det-batch` 從原本的 8 調小。要和官方 baseline 完全一致，請用附的權重（用法 A）。

---

## 8. 專案結構

```
aicup_pv_baseline/
├── pipeline.py              一鍵流程（各步驟也能單獨跑；主要參數見 python pipeline.py -h）
├── requirements.txt         套件版本（官方驗證時的版本）
├── data/                    放訓練集、測試集與 evaluation kit（見第 2 節）
├── weights/qwen_reason/     官方 baseline 用的 Qwen（已微調；model.safetensors 的 SHA-256：1cf45c00…4267862c；LICENSE 是 Apache-2.0 全文）
├── tools/
│   ├── ir_gray.py           偽彩色 IR → 灰階（每張影像各自用標準亮度公式，不需標註、不學參數）
│   └── labelme2yolo.py      訓練集標註 → YOLO 格式（重訓偵測器才需要）
├── prb/                     PRB-FPN / YOLOv7 偵測器
│   ├── train.py  detect.py  test.py  models/  utils/  cfg/
│   ├── yolo7.pt             預訓練權重（重訓偵測器用）
│   └── runs/train/pv/       已訓練好的偵測器：weights/best.pt、訓練紀錄 results.txt、opt.yaml（原始訓練參數；伺服器路徑中的使用者名稱已移除）
├── reason/                  成因說明（Qwen）
│   ├── common.py            讀標註、把偵測結果寫成 prompt（訓練與推論共用）
│   ├── build_sft_data.py    訓練集標註 → SFT 訓練資料與候選句
│   ├── train_sft.py         SFT 訓練（只對回答算 loss，可選 LoRA）
│   ├── reasoner.py          載入模型、generate / snap / rank
│   ├── eval_val.py          驗證集上的成因群組準確率、純規則 baseline
│   ├── yolo2dets.py         偵測輸出 → detections.json（含後處理）
│   └── infer_submission.py  detections + Qwen → submission.json（含簡易格式自檢）
└── outputs/                 所有產出（執行後才會出現）
    ├── test_IR_gray/                   轉成灰階的測試集 IR
    ├── detect/test_{EO,IR}/labels/     偵測器原始輸出
    ├── detect/_detect.json             detect 跑完才寫入：用了哪個權重、哪份測試資料、--det-img
    ├── detections.json                 過濾與後處理後的偵測結果
    ├── sft_data/                       train.jsonl、val.jsonl、candidates.json
    ├── qwen_reason/                    微調後的 Qwen（final/ 是最終版；checkpoint-* 是訓練中途的存檔）
    └── submission.json                 提交檔
```

---

## 9. 設計說明

### 評分（摘要）

`Score = 0.7 × F1_TIoU + 0.3 × F1_TEXT`

- **F1_TIoU**：只比較同一張影像、同類別的框（`solar_panel`、`hotspot`、`crack` 三類都算），依重疊程度給部分分數，不需要 IoU ≥ 0.5
  （和下一行 F1_TEXT 的「配對」是兩套不同的計算）；多個預測對到同一個標註時只保留分數最高的一個，其餘記 0 但仍計入分母；
  各類別算出 F1 後取平均；沒有信心分數。
- **F1_TEXT**：只對與標註配對成功（同類別、IoU ≥ 0.5、一對一）的異常計分。`reason` 與該異常所屬成因類別的每一個參考描述計算 BERTScore，取最高值；
  `reason` 空白記 0。先在每個成因類別內平均，再跨類別取調和平均得到 raw，最後換算 F1_TEXT = (raw − 0.30) ÷ 0.40，並限制在 0～1。
  任一成因類別完全沒有配對成功的標註，或某類平均 ≤ 0 時，F1_TEXT = 0。

完整規則以官方 evaluation kit 為準（第 5～8 節與常見問題）。

### baseline 為什麼預設把 reason 對齊到訓練集的句子

baseline 預設用 `snap`（`--mode rank` 也一樣），讓每個框的 reason 一定是訓練集出現過的完整繁體中文句子：0.5B 的小模型偶爾會寫出殘缺或不通順的句子，
對齊後可以確保輸出完整、語句通順。這是 baseline 的工程選擇；想直接使用模型生成的句子，可以改用 `--mode generate`（見 4-7）。
成因類別與參考描述不公開，計分方式以官方 evaluation kit 為準。

### 為什麼 prompt 要放「同編號另一模態」的偵測結果

訓練集標註統計顯示，成因大多由「同編號 EO／IR 的另一張有沒有異常」加上場景決定（成因群組由 `approx_group()` 關鍵字規則近似，不是官方分類）：

| 情境 | 成因 | 筆數 |
|---|---|---|
| EO crack，同編號 IR 有 hotspot | 破裂影響導電 | 285 / 308 |
| IR hotspot，同編號 EO 有 crack | 模組板破裂 | 191 / 215 |
| IR hotspot，EO 無異常，面板約 73 片 | 隱裂或電性異常 | 190 |
| IR hotspot，多數 EO 無異常，面板約 17 片 | 旁路二極體 / 電池串 | 38 |
| IR hotspot，EO 有 crack，面板 9 片 | 電池片裂紋 | 17 |
| EO crack，IR 無異常 | 表層局部破損 35、外力撞擊 8（另 1 筆破裂影響導電） | 44 |

只看「同編號另一模態有沒有異常」這一條規則（crack：有→破裂影響導電、無→表層局部破損；hotspot：有→模組板破裂、無→隱裂或電性異常，
也就是 4-6 的純規則 baseline），在驗證集上就有約 89% 的群組準確率，但少數成因（旁路二極體、電池片裂紋）全錯，近似群組的調和平均直接變 0。
所以 prompt 放了面板數量、框的大小等場景資訊，訓練時也對少數成因過採樣，讓模型去學規則抓不到的情況。
附的權重在驗證集上把這兩類補回到 6/7、3/3，但「表層局部破損」變成 0/9，這是 baseline 還能改進的地方。
這也代表 **EO 上的破裂偵測得好不好，會直接影響 IR 熱點的 reason 正確率**。

### 對原始 PRB-FPN 程式的修改

- 相容性修補（新版 torch／numpy 會直接報錯）：
  - `torch.load(...)` 加上 `weights_only=False`（torch ≥ 2.6 預設改成 True，載不了 YOLOv7 權重）：`models/experimental.py`、`train.py`、`train_aux.py`、`utils/general.py`、`utils/datasets.py`
  - `.astype(np.int)` → `.astype(int)`（numpy ≥ 1.24 移除 `np.int`）：`utils/datasets.py`、`utils/general.py`
  - 讀圖改用 `np.fromfile` + `cv2.imdecode`（`utils/datasets.py` 的 `imread_u`）：Windows 上 `cv2.imread` 讀不到含中文的路徑
  - `utils/google_utils.py` 的 `attempt_download`：不再把權重路徑轉成小寫（Linux 路徑分大小寫，轉了會找不到權重而去連 GitHub），連線加上逾時
- `pipeline.py` 呼叫這些程式時設定 `PYTHONUTF8=1`，專案放在含中文的路徑時，`train-det` 讀寫設定檔也不會出錯。
- 刪掉用不到的檔案：`deploy/`、`tools/`（展示用 notebook）、`figure/`、`inference/`、`scripts/`、`utils/aws`、`utils/google_app_engine`、
  `traced_model.pt`（pipeline 用 `--no-trace` 不需要）、`runs/train/pv/weights/last.pt`（只在續訓時需要）、tensorboard event 檔。
- 新增 `tools/labelme2yolo.py`：依現有權重的類別順序（`crack, hotspot, solar_panel`），把訓練集的 labelme 標註轉成 YOLO 格式。

### 注意事項

- 程式不讀取任何測試集答案；測試影像只用到像素本身（每張熱影像各自轉灰階、偵測），不從測試資料擬合任何參數。

---

## 10. 授權

- `prb/`：PRB-FPN／YOLOv7 偵測器程式，GPL-3.0（見 `prb/LICENSE.md`）。
- `weights/qwen_reason/`：由 [Qwen/Qwen2.5-0.5B-Instruct](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct)（Apache-2.0）以本比賽訓練集微調（SFT）而來，權重已修改；授權全文見 `weights/qwen_reason/LICENSE`。
