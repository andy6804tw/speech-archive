AI Cup 參賽資料的放置方式（訓練集、測試集與官方 evaluation kit）：

```
data/
├── train/                      訓練集，1046 組
│   ├── EO/image/*.jpg  EO/label/*.json     可見光 1920x1080，labelme 多邊形 + reason
│   └── IR/image/*.jpg  IR/label/*.json     熱影像 640x512
├── test/                       測試集，696 組（EO + IR 共 1392 張）
│   ├── EO/image/*.jpg
│   └── IR/image/*.jpg
├── test_images.csv             全部測試影像的 key（官方 evaluation kit 內附，make_submission.py 需要）
├── make_submission.py          官方提交檔範本產生與格式檢查工具（evaluation kit 內附）
└── sample_submission.json      官方提交格式範例（evaluation kit 內附）
```

同編號的 EO 與 IR（例如 `train_0001.jpg`）拍的是同一處，`pipeline.py` 會把兩者的偵測結果一起給 Qwen 判斷成因。

檢查提交檔格式：
```bash
python data/make_submission.py --check outputs/submission.json
```

