# -*- coding: utf-8 -*-
"""在 val 切分上看 SFT 模型的成因判斷準不準。

一般用 python pipeline.py eval。直接執行時：
    python reason/eval_val.py --data outputs/sft_data --model outputs/qwen_reason/final --mode snap
    python reason/eval_val.py --data outputs/sft_data --baseline   # 不用模型：只看「另一模態有沒有異常」的規則

指標：
  group acc  以 common.approx_group 關鍵字規則分群後的成因群組準確率（F1_TEXT 的 proxy）
  exact      與標註原句完全相同的比例（參考用）
注意 val 用的是 GT 框，測試時用的是 PRB 偵測框，實際分數還會受偵測品質影響。
"""
import argparse
import collections
import json
import os
import re

from common import approx_group


def baseline(prompt, label, cands):
    """規則：另一模態同編號影像有沒有異常 → 選該情境最常見的句子。"""
    m = re.search(r"同編號.*?hotspot (\d+) 個、crack (\d+) 個", prompt)
    paired = m and (int(m.group(1)) + int(m.group(2)) > 0)
    if label == "crack":
        want = "crack/破裂影響導電" if paired else "crack/表層局部破損"
    else:
        want = "hotspot/模組板破裂" if paired else "hotspot/隱裂或電性異常"
    return next(s for s in cands[label] if approx_group(label, s) == want)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="sft_data")
    ap.add_argument("--model")
    ap.add_argument("--mode", choices=["generate", "snap", "rank"], default="snap")
    ap.add_argument("--baseline", action="store_true")
    ap.add_argument("--show-errors", type=int, default=10)
    args = ap.parse_args()

    recs = [json.loads(l) for l in open(os.path.join(args.data, "val.jsonl"), encoding="utf-8") if l.strip()]
    cands = {k: [s for s, _ in v] for k, v in
             json.load(open(os.path.join(args.data, "candidates.json"), encoding="utf-8")).items()}
    prompts = [r["messages"][1]["content"] for r in recs]
    labels = [r["label"] for r in recs]
    gold = [r["messages"][2]["content"] for r in recs]

    if args.baseline:
        preds = [baseline(p, l, cands) for p, l in zip(prompts, labels)]
    else:
        import reasoner
        tok, model = reasoner.load(args.model)
        preds = reasoner.predict(tok, model, prompts, labels, cands, mode=args.mode)

    per = collections.defaultdict(lambda: [0, 0])
    exact, errs = 0, []
    for r, p, g, l in zip(recs, preds, gold, labels):
        gg, pg = approx_group(l, g), approx_group(l, p)
        per[gg][0] += gg == pg
        per[gg][1] += 1
        exact += p == g
        if gg != pg:
            errs.append((r["id"], gg, pg, p))
    n = len(recs)
    acc = sum(v[0] for v in per.values()) / n
    print("val {} 筆  group acc {:.3f}  exact {:.3f}".format(n, acc, exact / n))
    for g, (c, t) in sorted(per.items()):
        print("  {:<28s} {:3d}/{:3d}  {:.2f}".format(g, c, t, c / t))
    # 官方跨群組取調和平均，某個群組全錯就會被拖很低
    recalls = [c / t for c, t in per.values()]
    hm = 0 if min(recalls) == 0 else len(recalls) / sum(1 / x for x in recalls)
    print("各群組 recall 的調和平均 {:.3f}（接近官方的聚合方式）".format(hm))
    for e in errs[:args.show_errors]:
        print("  錯：{}  gold={}  pred={}  「{}」".format(*e))


if __name__ == "__main__":
    main()
