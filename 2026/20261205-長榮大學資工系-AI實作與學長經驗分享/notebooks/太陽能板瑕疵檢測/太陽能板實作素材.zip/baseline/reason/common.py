# -*- coding: utf-8 -*-
"""訓練與推論共用：讀標註、把「一個瑕疵框 + 周邊偵測結果」轉成給 LLM 的文字描述。

訓練時描述來自 GT 標註，推論時來自 PRB 偵測結果，兩邊必須走同一個 describe()，
否則模型在測試時看到的輸入分布會跟訓練時不一樣。
"""
import json
import re
import statistics

CLASSES = ("solar_panel", "hotspot", "crack")
ANOMALY = ("hotspot", "crack")
MODS = ("EO", "IR")
MOD_DESC = {"EO": "可見光(EO)", "IR": "熱影像(IR)"}
LABEL_DESC = {"solar_panel": "面板", "hotspot": "熱點(hotspot)", "crack": "破裂(crack)"}

SYSTEM_PROMPT = (
    "你是太陽能電廠的無人機巡檢工程師。根據瑕疵偵測結果（含同一位置的可見光與熱影像），"
    "用一句繁體中文說明該瑕疵最可能的成因。"
)


def bbox(points):
    xs = [float(p[0]) for p in points]
    ys = [float(p[1]) for p in points]
    return min(xs), min(ys), max(xs), max(ys)


def load_labelme(path):
    """回傳 (W, H, objs)，objs = [{label, points, box, reason}]"""
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    objs = []
    for s in d.get("shapes", []):
        if s.get("label") not in CLASSES or len(s.get("points") or []) < 2:
            continue
        objs.append({
            "label": s["label"],
            "points": s["points"],
            "box": bbox(s["points"]),
            "reason": (s.get("reason") or "").strip(),
        })
    return d.get("imageWidth"), d.get("imageHeight"), objs


def paired_key(key):
    """test/EO/image/test_001.jpg <-> test/IR/image/test_001.jpg"""
    if "/EO/" in key:
        return key.replace("/EO/", "/IR/")
    return key.replace("/IR/", "/EO/")


def mod_of(key):
    return "IR" if "/IR/" in key else "EO"


def _area(b):
    return max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])


def _inter(a, b):
    return _area((max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])))


def _counts(objs):
    c = {k: 0 for k in CLASSES}
    for o in objs:
        c[o["label"]] += 1
    return c


def _panel_med(objs):
    a = [_area(o["box"]) for o in objs if o["label"] == "solar_panel"]
    return statistics.median(a) if a else None


def _pos(box, W, H):
    cx = (box[0] + box[2]) / 2 / W * 100
    cy = (box[1] + box[3]) / 2 / H * 100
    return "({:.0f}%, {:.0f}%)".format(cx, cy)


def describe(target, objs, W, H, mod, paired_objs, paired_W, paired_H):
    """target: 要說明的異常物件；objs: 同張影像所有物件（含 target）；
    paired_objs: 同編號另一模態影像的物件（沒有那張影像就給 None）。"""
    x0, y0, x1, y1 = target["box"]
    w, h = max(1.0, x1 - x0), max(1.0, y1 - y0)
    lines = [
        "影像類型：{}，{}x{}".format(MOD_DESC[mod], W, H),
        "待說明瑕疵：{}".format(LABEL_DESC[target["label"]]),
        "瑕疵位置：中心{}，寬佔 {:.1f}%、高佔 {:.1f}%，長寬比 {:.1f}".format(
            _pos(target["box"], W, H), w / W * 100, h / H * 100, max(w, h) / min(w, h)),
    ]
    med = _panel_med(objs)
    if med:
        n_ov = sum(1 for o in objs if o["label"] == "solar_panel"
                   and _inter(o["box"], target["box"]) > 0.2 * min(_area(o["box"]), w * h))
        lines.append("瑕疵面積約為單片面板的 {:.2f} 倍，與 {} 片面板重疊".format(w * h / med, n_ov))
    else:
        lines.append("此影像未偵測到面板")
    c = _counts(objs)
    lines.append("同一張影像：面板 {} 片、hotspot {} 個、crack {} 個".format(
        c["solar_panel"], c["hotspot"], c["crack"]))

    other = "IR" if mod == "EO" else "EO"
    if paired_objs is None:
        lines.append("同編號{}影像：無".format(MOD_DESC[other]))
    else:
        pc = _counts(paired_objs)
        s = "同編號{}影像：面板 {} 片、hotspot {} 個、crack {} 個".format(
            MOD_DESC[other], pc["solar_panel"], pc["hotspot"], pc["crack"])
        pan = [o for o in paired_objs if o["label"] in ANOMALY]
        if pan:
            pan.sort(key=lambda o: -_area(o["box"]))
            s += "；異常位置 " + "、".join(
                "{}{}".format(o["label"], _pos(o["box"], paired_W, paired_H)) for o in pan[:3])
        lines.append(s)
    lines.append("請說明此瑕疵的可能成因。")
    return "\n".join(lines)


def build_messages(prompt, answer=None):
    msgs = [{"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt}]
    if answer is not None:
        msgs.append({"role": "assistant", "content": answer})
    return msgs


def approx_group(label, reason):
    """只供本地驗證用的「成因群組」近似分類（以關鍵字把 train reason 分群，非官方成因類別）。
    官方 F1_TEXT 以參考描述計算 BERTScore，細節見官方 evaluation kit；這裡只當本地 proxy 指標。"""
    r = reason or ""
    if label == "crack":
        if re.search("衝擊|撞擊|外力|外物", r):
            return "crack/外力撞擊"
        if re.search("導電|電流|電性", r):
            return "crack/破裂影響導電"
        return "crack/表層局部破損"
    if re.search("旁路|電池串|整串", r):
        return "hotspot/旁路二極體或電池串"
    if re.search("模組板|破裂|破損|龜裂|碎裂|裂損", r):
        return "hotspot/模組板破裂"
    if re.search("隱裂|電性|微裂|接觸|內部", r):
        return "hotspot/隱裂或電性異常"
    if re.search("裂紋", r):
        return "hotspot/電池片裂紋"
    return "hotspot/其他"
