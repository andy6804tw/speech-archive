# -*- coding: utf-8 -*-
"""把 train 標註轉成 SFT 資料（chat messages 格式的 jsonl）。

    python reason/build_sft_data.py --train-root data/train --out outputs/sft_data

產出：
  sft_data/train.jsonl   訓練集（含擴增）
  sft_data/val.jsonl     驗證集（依影像編號切，EO/IR 同編號一定在同一邊）
  sft_data/candidates.json  每個類別在 train 中出現過的 reason 句子（推論時 snap / rank 用）
"""
import argparse
import collections
import copy
import json
import math
import os
import random

from common import ANOMALY, MODS, approx_group, build_messages, describe, load_labelme


def jitter(objs, W, H, rng, box_noise=0.02, drop_panel=0.05):
    """模擬偵測器誤差：框座標小幅抖動、少數面板漏檢。異常框不丟，因為它們是成因判斷的關鍵。"""
    out = []
    for o in objs:
        if o["label"] == "solar_panel" and rng.random() < drop_panel:
            continue
        o = copy.copy(o)
        x0, y0, x1, y1 = o["box"]
        w, h = x1 - x0, y1 - y0
        d = lambda s: rng.uniform(-box_noise, box_noise) * s
        o["box"] = (max(0, x0 + d(w)), max(0, y0 + d(h)), min(W, x1 + d(w)), min(H, y1 + d(h)))
        out.append(o)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train-root", required=True, help="含 EO/label 與 IR/label 的 train 目錄")
    ap.add_argument("--out", default="sft_data")
    ap.add_argument("--val-ratio", type=float, default=0.15)
    ap.add_argument("--aug", type=int, default=2, help="每筆訓練樣本額外產生幾份抖動版本")
    ap.add_argument("--min-group", type=int, default=150, help="少數成因群組過採樣到約這個筆數；0 = 不平衡")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    ann = {}  # (mod, stem) -> (W, H, objs)
    for mod in MODS:
        d = os.path.join(args.train_root, mod, "label")
        for fn in sorted(os.listdir(d)):
            if fn.endswith(".json"):
                ann[(mod, fn[:-5])] = load_labelme(os.path.join(d, fn))
    stems = sorted({s for _, s in ann})
    rng = random.Random(args.seed)
    val_stems = set(rng.sample(stems, int(len(stems) * args.val_ratio)))

    # 以 approx_group() 把訓練集 reason 近似分群（本地分法，非官方成因類別）。官方 F1_TEXT 跨成因類別取調和平均，
    # 筆數少的類別若全錯會拖低整項，所以訓練集對筆數少的近似群組多做幾份抖動版本，讓每群至少約 --min-group 筆
    gcount = collections.Counter(
        approx_group(o["label"], o["reason"])
        for (mod, stem), (_, _, objs) in ann.items() if stem not in val_stems
        for o in objs if o["label"] in ANOMALY and o["reason"])

    os.makedirs(args.out, exist_ok=True)
    cands = {k: collections.Counter() for k in ANOMALY}
    n = collections.Counter()
    with open(os.path.join(args.out, "train.jsonl"), "w", encoding="utf-8") as ftr, \
            open(os.path.join(args.out, "val.jsonl"), "w", encoding="utf-8") as fva:
        for stem in stems:
            split = "val" if stem in val_stems else "train"
            for mod in MODS:
                if (mod, stem) not in ann:
                    continue
                W, H, objs = ann[(mod, stem)]
                other = "IR" if mod == "EO" else "EO"
                pW, pH, pobjs = ann.get((other, stem), (None, None, None))
                for i, t in enumerate(objs):
                    if t["label"] not in ANOMALY or not t["reason"]:
                        continue
                    cands[t["label"]][t["reason"]] += 1
                    marked = [dict(o, _target=(j == i)) for j, o in enumerate(objs)]
                    variants = [(marked, pobjs)]
                    if split == "train":
                        g = gcount[approx_group(t["label"], t["reason"])]
                        for _ in range(max(args.aug, math.ceil(args.min_group / g) - 1)):
                            variants.append((jitter(marked, W, H, rng),
                                             jitter(pobjs, pW, pH, rng) if pobjs is not None else None))
                    for vo, vp in variants:
                        tgt = next(o for o in vo if o["_target"])  # 抖動版要用抖動後的 target 框
                        prompt = describe(tgt, vo, W, H, mod, vp, pW, pH)
                        rec = {"id": "{}/{}#{}".format(mod, stem, i), "label": t["label"],
                               "messages": build_messages(prompt, t["reason"])}
                        (fva if split == "val" else ftr).write(json.dumps(rec, ensure_ascii=False) + "\n")
                        n[split] += 1

    with open(os.path.join(args.out, "candidates.json"), "w", encoding="utf-8") as f:
        json.dump({k: v.most_common() for k, v in cands.items()}, f, ensure_ascii=False, indent=1)
    print("train {} 筆、val {} 筆（val 影像編號 {} 個）".format(n["train"], n["val"], len(val_stems)))
    print("候選句：" + "、".join("{} {} 句".format(k, len(v)) for k, v in cands.items()))


if __name__ == "__main__":
    main()
