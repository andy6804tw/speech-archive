# -*- coding: utf-8 -*-
"""PRB 偵測結果 + SFT 後的 Qwen → 最終 submission.json

一般用 python pipeline.py submit。直接執行時：
    python reason/infer_submission.py --dets outputs/detections.json --model outputs/qwen_reason/final \
        --candidates outputs/sft_data/candidates.json --mode snap --out outputs/submission.json
"""
import argparse
import collections
import json
import math

from common import ANOMALY, CLASSES, bbox, describe, mod_of, paired_key


def to_objs(entry):
    return [dict(o, box=bbox(o["points"])) for o in entry["objects"]]


def validate(sub, valid_keys):
    """簡易格式自我檢查：只涵蓋官方 make_submission.py --check 的部分規則，上傳前仍須執行官方檢查。"""
    errs = []
    total = 0
    for k, objs in sub.items():
        if k not in valid_keys:
            errs.append("未知影像 " + k)
        if len(objs) > 500:
            errs.append("{} 物件數 {} > 500".format(k, len(objs)))
        total += len(objs)
        for o in objs:
            if o["label"] not in CLASSES:
                errs.append("{} label {}".format(k, o["label"]))
            if not 2 <= len(o["points"]) <= 100:
                errs.append("{} points 數量".format(k))
            for x, y in o["points"]:
                if not (math.isfinite(x) and math.isfinite(y)) or abs(x) > 1e6 or abs(y) > 1e6:
                    errs.append("{} 座標異常".format(k))
            if o["label"] in ANOMALY and len(o.get("reason") or "") > 500:
                errs.append("{} reason 超過 500 字".format(k))
    if total > 400000:
        errs.append("總物件數 {} > 400000".format(total))
    return errs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dets", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--candidates", required=True)
    ap.add_argument("--mode", choices=["generate", "snap", "rank"], default="snap")
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--out", default="submission.json")
    args = ap.parse_args()

    dets = json.load(open(args.dets, encoding="utf-8"))
    cands = {k: [s for s, _ in v] for k, v in json.load(open(args.candidates, encoding="utf-8")).items()}
    objs = {k: to_objs(v) for k, v in dets.items()}

    jobs = []  # (key, index, prompt, label)
    for k, os_ in objs.items():
        e = dets[k]
        pk = paired_key(k)
        pobjs = objs.get(pk)
        pW, pH = (dets[pk]["width"], dets[pk]["height"]) if pk in dets else (None, None)
        for i, o in enumerate(os_):
            if o["label"] in ANOMALY:
                jobs.append((k, i, describe(o, os_, e["width"], e["height"], mod_of(k), pobjs, pW, pH),
                             o["label"]))
    print("異常物件 {} 個，開始產生 reason（mode={}）".format(len(jobs), args.mode))

    reasons = []
    if jobs:
        import reasoner
        tok, model = reasoner.load(args.model)
        reasons = reasoner.predict(tok, model, [j[2] for j in jobs], [j[3] for j in jobs], cands,
                                   mode=args.mode, bs=args.bs)

    rmap = {(k, i): r for (k, i, _, _), r in zip(jobs, reasons)}
    sub = {}
    for k, os_ in objs.items():
        sub[k] = []
        for i, o in enumerate(os_):
            rec = {"label": o["label"], "points": o["points"]}
            if o["label"] in ANOMALY:
                rec["reason"] = rmap[(k, i)] or cands[o["label"]][0]  # 空字串會記 0 分，至少給一句
            sub[k].append(rec)

    errs = validate(sub, set(dets))
    if errs:
        print("格式檢查失敗：", errs[:20])
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(sub, f, ensure_ascii=False)
    print("已寫入 {}（{} 張影像、{} 個物件）".format(args.out, len(sub), sum(map(len, sub.values()))))
    for lab in ANOMALY:
        c = collections.Counter(r for (k, i, _, l), r in zip(jobs, reasons) if l == lab)
        print("\n[{}] 前幾名 reason：".format(lab))
        for s, n in c.most_common(8):
            print("  {:4d}  {}".format(n, s))


if __name__ == "__main__":
    main()
