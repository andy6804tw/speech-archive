# -*- coding: utf-8 -*-
"""載入 SFT 後的 Qwen，產生 reason。三種輸出方式：

  generate : 自由生成（greedy、不抽樣；會沿用模型 generation_config.json 的 repetition_penalty 1.1）
  snap     : 自由生成後，貼齊到 train 出現過最相近的句子（預設）
  rank     : 不生成，直接用模型對「該類別所有候選句」算平均 log-prob，取最高者

snap / rank 輸出的一定是 train 出現過的完整句子：格式合法、語氣一致，0.5B 模型偶爾寫歪也不會產生殘句。
"""
import difflib

import torch
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer

from common import build_messages


def load(model_dir, device=None):
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    # V100 等 Ampere 以前的卡沒有原生 bf16；0.5B 用 fp32 推論也很快，最穩
    dtype = (torch.bfloat16 if device == "cuda" and torch.cuda.get_device_capability()[0] >= 8
             else torch.float32)
    major, minor = (int(x) for x in transformers.__version__.split(".")[:2])
    kw = {"dtype": dtype} if (major, minor) >= (4, 56) else {"torch_dtype": dtype}
    tok = AutoTokenizer.from_pretrained(model_dir)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(model_dir, **kw).to(device).eval()
    return tok, model


def _prompt_text(tok, prompt):
    return tok.apply_chat_template(build_messages(prompt), tokenize=False, add_generation_prompt=True)


@torch.no_grad()
def generate(tok, model, prompts, bs=32, max_new_tokens=80):
    tok.padding_side = "left"
    out = []
    for i in range(0, len(prompts), bs):
        texts = [_prompt_text(tok, p) for p in prompts[i:i + bs]]
        enc = tok(texts, return_tensors="pt", padding=True, add_special_tokens=False).to(model.device)
        gen = model.generate(**enc, max_new_tokens=max_new_tokens, do_sample=False,
                             pad_token_id=tok.pad_token_id)
        for g in gen[:, enc["input_ids"].shape[1]:]:
            out.append(tok.decode(g, skip_special_tokens=True).strip())
    return out


def snap(text, candidates):
    """貼齊到字面最相近的候選句。"""
    if not candidates:
        return text
    if text in candidates:
        return text
    return max(candidates, key=lambda c: difflib.SequenceMatcher(None, text, c).ratio())


@torch.no_grad()
def rank(tok, model, prompts, cand_lists, bs=32):
    """對每個 prompt，在其候選句中挑模型平均 log-prob 最高的一句。"""
    out = []
    backbone, head = model.get_decoder(), model.get_output_embeddings()
    for prompt, cands in zip(prompts, cand_lists):
        p_ids = tok(_prompt_text(tok, prompt), add_special_tokens=False)["input_ids"]
        c_ids = [tok(c + "<|im_end|>", add_special_tokens=False)["input_ids"] for c in cands]
        s = len(p_ids) - 1  # 第一個回答 token 由位置 len(p_ids)-1 的輸出預測
        scores = []
        for i in range(0, len(cands), bs):
            chunk = c_ids[i:i + bs]
            m = max(len(c) for c in chunk)
            ids = torch.full((len(chunk), len(p_ids) + m), tok.pad_token_id, dtype=torch.long)
            att = torch.zeros_like(ids)
            for j, c in enumerate(chunk):
                ids[j, :len(p_ids) + len(c)] = torch.tensor(p_ids + c)
                att[j, :len(p_ids) + len(c)] = 1
            ids, att = ids.to(model.device), att.to(model.device)
            h = backbone(input_ids=ids, attention_mask=att).last_hidden_state[:, s:s + m]
            # 只在回答區段過 lm_head，否則 batch×seq×15 萬詞表的 logits 會吃掉十幾 GB
            logp = torch.log_softmax(head(h).float(), -1)
            tgt = logp.gather(-1, ids[:, s + 1:s + 1 + m].unsqueeze(-1)).squeeze(-1)
            for j, c in enumerate(chunk):
                scores.append(tgt[j, :len(c)].mean().item())
        out.append(cands[max(range(len(cands)), key=scores.__getitem__)])
    return out


def predict(tok, model, prompts, labels, candidates, mode="snap", bs=32):
    """candidates: {label: [句子, ...]}"""
    if mode == "rank":
        return rank(tok, model, prompts, [candidates[l] for l in labels])
    texts = generate(tok, model, prompts, bs=bs)
    if mode == "snap":
        texts = [snap(t, candidates[l]) for t, l in zip(texts, labels)]
    return texts
