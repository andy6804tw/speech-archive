# -*- coding: utf-8 -*-
"""把 PRB (YOLOv7) detect.py 的 --save-txt 輸出轉成 detections.json。

一般用 python pipeline.py detect dets 就好（它會依序跑偵測與這支轉換）。要手動跑的話：
先在 prb/ 底下分別對 EO、IR 跑 detect.py（兩個模態檔名相同，所以要分兩個輸出目錄；IR 要用 ir-norm 轉好的灰階圖）：
    python detect.py --weights runs/train/pv/weights/best.pt --source <test>/EO/image --img-size 1280 \
        --conf-thres 0.05 --iou-thres 0.45 --save-txt --save-conf --nosave --no-trace \
        --project <work>/detect --name test_EO --exist-ok
    （IR 同理：--source <work>/test_IR_gray --name test_IR）
detect.py 以附加模式寫 txt，重跑前要先刪掉舊的輸出資料夾，否則框會重複。

再轉換：
    python reason/yolo2dets.py --test-root data/test \
        --eo-labels <work>/detect/test_EO/labels --ir-labels <work>/detect/test_IR/labels \
        --prb-dir prb --weights prb/runs/train/pv/weights/best.pt --out <work>/detections.json

類別順序從權重檔讀（需要 torch 與 PRB 原始碼）；沒有的話用 --names 依 data.yaml 的順序手動給。
detect.py 先用低 conf 跑，這裡再依類別過濾 —— 改門檻不必重跑偵測。
評分沒有信心分數、所有送出的框都進 Precision 分母，門檻值得在驗證集上調。
"""
import argparse
import json
import os
import sys

from PIL import Image

from common import ANOMALY, CLASSES, MODS

# train 標註統計（data/train）：hotspot 444 個全在 IR、crack 352 個全在 EO；
# 異常框與 solar_panel 框不重疊（異常標註直接取代該片面板，IoU>=0.5 的只有 1/796）
ALLOWED = {"EO": {"solar_panel", "crack"}, "IR": {"solar_panel", "hotspot"}}


def _iou(a, b):
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    u = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / u if u > 0 else 0.0


def postprocess(objs, mod):
    """依 train 標註規則清理：拿掉不可能出現的類別；異常框位置上的面板框刪掉（避免同一片面板重複計分）。"""
    objs = [o for o in objs if o["label"] in ALLOWED[mod]]
    anom = [o["_box"] for o in objs if o["label"] in ANOMALY]
    return [o for o in objs if not (o["label"] == "solar_panel" and any(_iou(o["_box"], a) >= 0.5 for a in anom))]


def names_from_weights(prb_dir, weights):
    sys.path.insert(0, os.path.abspath(prb_dir))  # 權重是 pickle 的整個模型，需要 PRB 的 models/ 才能載入
    import torch
    ck = torch.load(weights, map_location="cpu", weights_only=False)
    m = ck["ema"] if ck.get("ema") is not None else ck["model"]
    names = m.names if hasattr(m, "names") else m.module.names
    return list(names.values()) if isinstance(names, dict) else list(names)


def parse_conf(s):
    """"solar_panel=0.3,hotspot=0.25,crack=0.25" → dict；格式不對或類別名稱打錯就停下來說明。"""
    usage = "--conf 的格式是 solar_panel=0.25,hotspot=0.25,crack=0.25（類別名稱全小寫、用逗號分隔、不要有空格）"
    out = {}
    for kv in s.split(","):
        if kv.count("=") != 1:
            sys.exit("看不懂 --conf 的「{}」。{}".format(kv, usage))
        k, v = kv.split("=")
        k = k.strip()
        if k not in CLASSES:
            sys.exit("--conf 裡的類別「{}」不存在，只能是 {}。{}".format(k, CLASSES, usage))
        try:
            out[k] = float(v)
        except ValueError:
            sys.exit("--conf 裡 {} 的門檻「{}」不是數字。{}".format(k, v, usage))
        if not 0 <= out[k] <= 1:
            sys.exit("--conf 裡 {} 的門檻 {} 要介於 0 到 1。".format(k, out[k]))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--test-root", required=True, help="含 EO/image 與 IR/image 的 test 目錄")
    ap.add_argument("--eo-labels", required=True)
    ap.add_argument("--ir-labels", required=True)
    ap.add_argument("--names", help="逗號分隔，依訓練 data.yaml 的類別順序；附的權重是 crack,hotspot,solar_panel")
    ap.add_argument("--prb-dir")
    ap.add_argument("--weights")
    ap.add_argument("--conf", default="solar_panel=0.25,hotspot=0.25,crack=0.25")
    ap.add_argument("--out", default="detections.json")
    ap.add_argument("--no-rules", action="store_true", help="不套用 train 標註規則的後處理（postprocess）")
    args = ap.parse_args()

    if args.names:
        names = [x.strip() for x in args.names.split(",")]
    elif args.weights and args.prb_dir:
        names = names_from_weights(args.prb_dir, args.weights)
    else:
        sys.exit("需要 --names，或 --prb-dir + --weights 以從權重讀類別順序")
    print("類別順序：", names)
    bad = [n for n in names if n not in CLASSES]
    if bad:
        sys.exit("類別 {} 不是 {}，請確認 --names".format(bad, CLASSES))
    conf = parse_conf(args.conf)
    print("各類別門檻：", {c: conf.get(c, 0.25) for c in CLASSES})
    for ldir in (args.eo_labels, args.ir_labels):
        if not os.path.isdir(ldir):
            sys.exit("找不到偵測結果資料夾 {}，請先跑 detect".format(ldir))

    out, stat = {}, {c: 0 for c in CLASSES}
    for mod, ldir in (("EO", args.eo_labels), ("IR", args.ir_labels)):
        idir = os.path.join(args.test_root, mod, "image")
        for fn in sorted(os.listdir(idir)):
            if not fn.lower().endswith((".jpg", ".jpeg", ".png")):
                continue
            with Image.open(os.path.join(idir, fn)) as im:
                W, H = im.size
            objs = []
            txt = os.path.join(ldir, os.path.splitext(fn)[0] + ".txt")
            if os.path.exists(txt):
                with open(txt) as f:
                    for line in f:
                        v = line.split()
                        if len(v) < 5:
                            continue
                        label = names[int(float(v[0]))]
                        c = float(v[5]) if len(v) > 5 else 1.0
                        if c < conf.get(label, 0.25):
                            continue
                        xc, yc, w, h = (float(x) for x in v[1:5])
                        x0, x1 = max(0.0, (xc - w / 2) * W), min(W, (xc + w / 2) * W)
                        y0, y1 = max(0.0, (yc - h / 2) * H), min(H, (yc + h / 2) * H)
                        if x1 - x0 < 1 or y1 - y0 < 1:
                            continue
                        objs.append({"label": label, "conf": round(c, 4), "_box": (x0, y0, x1, y1),
                                     "points": [[round(x0, 1), round(y0, 1)], [round(x1, 1), round(y0, 1)],
                                                [round(x1, 1), round(y1, 1)], [round(x0, 1), round(y1, 1)]]})
            if not args.no_rules:
                objs = postprocess(objs, mod)
            for o in objs:
                del o["_box"]
                stat[o["label"]] += 1
            out["test/{}/image/{}".format(mod, fn)] = {"width": W, "height": H, "objects": objs}

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False)
    print("{} 張影像；偵測數 {}；已寫入 {}".format(len(out), stat, args.out))


if __name__ == "__main__":
    main()
