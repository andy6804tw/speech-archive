# -*- coding: utf-8 -*-
"""Qwen2.5-0.5B-Instruct 的 SFT：只對 assistant 回答（reason）算 loss。

一般用 python pipeline.py train-sft（它會固定基礎模型的版本）。直接執行時：
    python reason/train_sft.py --data outputs/sft_data --out outputs/qwen_reason \
        --revision 7ae557604adf67be50417f59c2c2f167def9a775

直接用 transformers.Trainer + 手動 label mask，不依賴 TRL 的 API（TRL 版本間改動多）。
顯示記憶體主要靠調小 --bs 省（16 GB 顯卡建議 --bs 8，見 README 4-5）；--lora 在 batch 大時幾乎不省。
V100 不支援 bf16，--precision auto 會自動改用 fp16 混合精度；若 loss 出現 nan 改 --precision fp32。
開始訓練前會先刪掉舊的 <out>/final；訓練完成才寫入新的 final 與 train_args.json（訓練參數紀錄）。
"""
import argparse
import json
import os
import shutil
import sys

import torch
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer, Trainer, TrainingArguments


def load_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


class SFTDataset(torch.utils.data.Dataset):
    def __init__(self, recs, tok, max_len):
        self.items = []
        self.n_cut = self.n_empty = 0  # 超過 max_len 被截斷的筆數 / 回答整個被切掉的筆數
        for r in recs:
            msgs = r["messages"]
            prompt = tok.apply_chat_template(msgs[:-1], tokenize=False, add_generation_prompt=True)
            full = tok.apply_chat_template(msgs, tokenize=False)
            assert full.startswith(prompt), "chat template 的 prompt 不是 full 的前綴"
            # prompt 與回答分開 tokenize 再接起來，和推論時「先 tokenize prompt 再生成」一致
            p_ids = tok(prompt, add_special_tokens=False)["input_ids"]
            c_ids = tok(full[len(prompt):].rstrip("\n"), add_special_tokens=False)["input_ids"]
            ids = (p_ids + c_ids)[:max_len]
            labels = ([-100] * len(p_ids) + c_ids)[:max_len]
            self.items.append((ids, labels))
            if len(p_ids) + len(c_ids) > max_len:  # 截斷會先切掉回答
                self.n_cut += 1
                if len(p_ids) >= max_len:
                    self.n_empty += 1  # 題目本身就超過 max_len，回答整個被切掉（這筆完全學不到東西）

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        ids, labels = self.items[i]
        return {"input_ids": ids, "labels": labels}


def make_collator(pad_id):
    def collate(batch):
        L = max(len(b["input_ids"]) for b in batch)
        ids = torch.full((len(batch), L), pad_id, dtype=torch.long)
        lab = torch.full((len(batch), L), -100, dtype=torch.long)
        att = torch.zeros((len(batch), L), dtype=torch.long)
        for i, b in enumerate(batch):
            n = len(b["input_ids"])
            ids[i, :n] = torch.tensor(b["input_ids"])
            lab[i, :n] = torch.tensor(b["labels"])
            att[i, :n] = 1
        return {"input_ids": ids, "labels": lab, "attention_mask": att}
    return collate


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="sft_data")
    ap.add_argument("--model", default="Qwen/Qwen2.5-0.5B-Instruct")
    ap.add_argument("--revision", default=None,
                    help="Hugging Face 上模型的版本（commit hash）；固定版本才能重現。--model 是本機資料夾時不使用")
    ap.add_argument("--out", default="ckpt/qwen05b_reason")
    ap.add_argument("--epochs", type=float, default=4)
    ap.add_argument("--lr", type=float, default=2e-5, help="全參數建議 1e-5~3e-5；LoRA 建議 1e-4~3e-4")
    ap.add_argument("--bs", type=int, default=16)
    ap.add_argument("--grad-accum", type=int, default=1)
    ap.add_argument("--max-len", type=int, default=768)
    ap.add_argument("--lora", action="store_true")
    ap.add_argument("--lora-r", type=int, default=16)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--precision", choices=["auto", "bf16", "fp16", "fp32"], default="auto",
                    help="auto：Ampere 以上 (A100/30/40/50 系列) 用 bf16，V100/T4 等用 fp16 混合精度")
    args = ap.parse_args()

    hub = {} if os.path.isdir(args.model) or not args.revision else {"revision": args.revision}
    tok = AutoTokenizer.from_pretrained(args.model, **hub)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    prec = args.precision
    if prec == "auto":
        # 不用 torch.cuda.is_bf16_supported()：新版 torch 在 V100 上也回 True（算模擬），Trainer 卻會拒絕 bf16
        if not torch.cuda.is_available():
            prec = "fp32"
        else:
            prec = "bf16" if torch.cuda.get_device_capability()[0] >= 8 else "fp16"
    print("訓練精度：", prec)
    bf16 = prec == "bf16"
    # fp16 走混合精度，權重本身要是 fp32，否則 Trainer 無法 unscale 梯度
    dtype = torch.bfloat16 if bf16 else torch.float32
    major, minor = (int(x) for x in transformers.__version__.split(".")[:2])
    model = AutoModelForCausalLM.from_pretrained(
        args.model, **hub, **({"dtype": dtype} if (major, minor) >= (4, 56) else {"torch_dtype": dtype}))

    if args.lora:
        from peft import LoraConfig, get_peft_model
        model = get_peft_model(model, LoraConfig(
            r=args.lora_r, lora_alpha=args.lora_r * 2, lora_dropout=0.05, task_type="CAUSAL_LM",
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]))
        model.print_trainable_parameters()

    train_ds = SFTDataset(load_jsonl(os.path.join(args.data, "train.jsonl")), tok, args.max_len)
    val_path = os.path.join(args.data, "val.jsonl")
    val_ds = SFTDataset(load_jsonl(val_path), tok, args.max_len) if os.path.exists(val_path) else None
    if val_ds is not None and len(val_ds) == 0:
        val_ds = None
    print("train {} 筆、val {} 筆；最長序列 {} tokens".format(
        len(train_ds), len(val_ds) if val_ds else 0, max(len(x[0]) for x in train_ds.items)))
    for name, ds in (("train", train_ds), ("val", val_ds)):
        if ds is not None and ds.n_cut:
            print("警告：{} 有 {} 筆超過 --max-len {} 被截斷（回答的後段被切掉）".format(name, ds.n_cut, args.max_len))
        if ds is not None and ds.n_empty:
            sys.exit("{} 有 {} 筆的題目本身就超過 --max-len {}，回答完全被切掉、學不到東西。"
                     "請縮短 describe() 產生的題目，或加大 --max-len".format(name, ds.n_empty, args.max_len))

    # 先刪掉舊的 final：訓練中途中斷時不會留下舊模型，讓之後的 eval/submit 誤用
    final = os.path.join(args.out, "final")
    if os.path.isdir(final):
        print("刪除舊的", final)
        shutil.rmtree(final)

    targs = TrainingArguments(
        output_dir=args.out,
        num_train_epochs=args.epochs,
        learning_rate=args.lr,
        per_device_train_batch_size=args.bs,
        per_device_eval_batch_size=args.bs,
        gradient_accumulation_steps=args.grad_accum,
        lr_scheduler_type="cosine",
        warmup_ratio=0.05,
        weight_decay=0.0,
        bf16=bf16,
        fp16=prec == "fp16",
        logging_steps=10,
        eval_strategy="epoch" if val_ds else "no",
        save_strategy="epoch" if val_ds else "no",
        save_total_limit=1,
        load_best_model_at_end=bool(val_ds),
        metric_for_best_model="eval_loss",
        greater_is_better=False,
        report_to="none",
        remove_unused_columns=False,
        seed=args.seed,
    )
    trainer = Trainer(model=model, args=targs, train_dataset=train_ds, eval_dataset=val_ds,
                      data_collator=make_collator(tok.pad_token_id))
    trainer.train()

    model = trainer.model
    if args.lora:
        model = model.merge_and_unload()
    model.save_pretrained(final)
    tok.save_pretrained(final)
    with open(os.path.join(final, "train_args.json"), "w", encoding="utf-8") as f:
        json.dump({"epochs": args.epochs, "bs": args.bs, "lr": args.lr, "lora": args.lora, "precision": prec,
                   "model": args.model, "revision": args.revision, "n_train": len(train_ds),
                   "n_val": len(val_ds) if val_ds else 0}, f, ensure_ascii=False, indent=1)
    print("已存到", final)


if __name__ == "__main__":
    main()
