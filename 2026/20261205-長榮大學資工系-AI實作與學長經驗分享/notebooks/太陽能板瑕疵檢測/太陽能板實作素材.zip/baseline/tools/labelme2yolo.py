# -*- coding: utf-8 -*-
"""AI Cup train（labelme 多邊形）→ PRB/YOLOv7 訓練用的 YOLO 格式資料集 + data yaml。

    python tools/labelme2yolo.py --train-root data/train --out outputs/yolo_ds

輸出：
  outputs/yolo_ds/images/{train,val}/EO_train_0001.jpg   (EO、IR 同檔名，所以加模態前綴)
  outputs/yolo_ds/labels/{train,val}/EO_train_0001.txt   (cls xc yc w h，皆為 0~1)
  outputs/yolo_ds/pv.yaml

多邊形取外接矩形。類別順序預設 crack,hotspot,solar_panel —— 與現有 best.pt 一致，
改順序就必須重訓偵測器，而且 yolo2dets.py 會從新權重讀到新順序。
"""
import argparse
import json
import os
import random
import shutil


def place(src, dst):
    """先試硬連結省空間，不行再複製。硬連結和 data/train 的原檔是同一份資料：不要直接修改 yolo_ds 裡的影像。"""
    if os.path.exists(dst):
        os.remove(dst)
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train-root", required=True, help="含 EO/{image,label} 與 IR/{image,label}")
    ap.add_argument("--out", default="outputs/yolo_ds")
    ap.add_argument("--names", default="crack,hotspot,solar_panel")
    ap.add_argument("--modalities", default="EO,IR")
    ap.add_argument("--val-ratio", type=float, default=0.1)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    names = [x.strip() for x in args.names.split(",")]
    cls = {n: i for i, n in enumerate(names)}
    mods = [m.strip() for m in args.modalities.split(",")]
    out = os.path.abspath(args.out)
    # 先清掉上一次的結果：否則換了切分或 --train-root 後，舊檔案會留著（同一張圖可能同時出現在 train 與 val）
    for sub in ("images", "labels"):
        shutil.rmtree(os.path.join(out, sub), ignore_errors=True)
    for sub in ("images/train", "images/val", "labels/train", "labels/val"):
        os.makedirs(os.path.join(out, sub), exist_ok=True)

    stems = set()
    for m in mods:
        stems |= {os.path.splitext(f)[0] for f in os.listdir(os.path.join(args.train_root, m, "image"))}
    stems = sorted(stems)
    rng = random.Random(args.seed)
    n_val = int(len(stems) * args.val_ratio)
    if args.val_ratio > 0 and n_val == 0 and len(stems) > 1:
        n_val = 1  # 資料很少時至少留 1 個編號當驗證集，否則 train.py 找不到 val 影像會停下來
    val = set(rng.sample(stems, n_val))  # EO/IR 同編號落在同一邊

    n_img, n_box, skipped = 0, 0, 0
    for m in mods:
        idir, ldir = os.path.join(args.train_root, m, "image"), os.path.join(args.train_root, m, "label")
        for fn in sorted(os.listdir(idir)):
            stem, ext = os.path.splitext(fn)
            lp = os.path.join(ldir, stem + ".json")
            if not os.path.exists(lp):
                skipped += 1
                continue
            d = json.load(open(lp, encoding="utf-8"))
            W, H = d["imageWidth"], d["imageHeight"]
            lines = []
            for s in d["shapes"]:
                if s["label"] not in cls or len(s["points"]) < 2:
                    continue
                xs = [p[0] for p in s["points"]]
                ys = [p[1] for p in s["points"]]
                x0, x1 = max(0.0, min(xs)), min(float(W), max(xs))
                y0, y1 = max(0.0, min(ys)), min(float(H), max(ys))
                if x1 - x0 < 1 or y1 - y0 < 1:
                    continue
                lines.append("{} {:.6f} {:.6f} {:.6f} {:.6f}".format(
                    cls[s["label"]], (x0 + x1) / 2 / W, (y0 + y1) / 2 / H, (x1 - x0) / W, (y1 - y0) / H))
            split = "val" if stem in val else "train"
            name = "{}_{}".format(m, stem)
            place(os.path.join(idir, fn), os.path.join(out, "images", split, name + ext))
            with open(os.path.join(out, "labels", split, name + ".txt"), "w") as f:
                f.write("\n".join(lines) + ("\n" if lines else ""))
            n_img += 1
            n_box += len(lines)

    yaml_path = os.path.join(out, "pv.yaml")
    with open(yaml_path, "w", encoding="utf-8") as f:
        f.write("train: {}\n".format(os.path.join(out, "images", "train").replace("\\", "/")))
        f.write("val: {}\n".format(os.path.join(out, "images", "val").replace("\\", "/")))
        f.write("nc: {}\n".format(len(names)))
        f.write("names: [{}]\n".format(", ".join("'{}'".format(n) for n in names)))
    # YOLOv7 會在 labels/ 旁留 .cache，資料變動後要刪掉才會重讀
    for split in ("train", "val"):
        c = os.path.join(out, "labels", split + ".cache")
        if os.path.exists(c):
            os.remove(c)
    print("影像 {}、框 {}、缺標註略過 {}；val 編號 {} 個".format(n_img, n_box, skipped, len(val)))
    print("data yaml：", yaml_path)


if __name__ == "__main__":
    main()
