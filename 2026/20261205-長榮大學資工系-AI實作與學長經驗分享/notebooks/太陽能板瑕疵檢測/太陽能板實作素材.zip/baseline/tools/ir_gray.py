# -*- coding: utf-8 -*-
"""偽彩色熱影像 → 灰階（固定的標準公式，不從任何資料學參數）。

train 的 IR 全是灰階（R=G=B），test 的 IR 有一部分是偽彩色（用顏色表示溫度）。
偵測器只在灰階熱影像上學過熱點，所以先把偽彩色影像轉成灰階再偵測。

做法：每張影像各自判斷、各自轉換，不看其他影像，也不用任何標註。
  1. 判斷是不是彩色：灰階影像每個像素的 R、G、B 相同；三個通道的平均差距大於 COLOR_TOL 就當成彩色
     （COLOR_TOL 只是容許 JPEG 壓縮造成的小誤差）；
  2. 彩色影像用標準的亮度公式轉灰階（ITU-R BT.601：0.299 R + 0.587 G + 0.114 B，即 OpenCV 的 BGR2GRAY），
     理由是這份測試集的偽彩色是由暗到亮（暗紫、紅、橘、黃到白）的配色，越熱越亮；彩虹（rainbow）那類配色就不適用；
  3. 灰階影像原樣複製。

    python tools/ir_gray.py --images data/test/IR/image --out outputs/test_IR_gray
"""
import argparse
import os
import shutil

import cv2
import numpy as np

COLOR_TOL = 2.0  # 三通道平均差距 > 2 視為彩色（灰階影像是 0；只容許 JPEG 壓縮的小誤差）
MANIFEST = "_source_ir_gray.txt"  # 記錄這個輸出資料夾由哪些來源影像、用哪個方法轉出，pipeline 用來檢查是否過期


def read(path):
    im = cv2.imdecode(np.fromfile(path, np.uint8), cv2.IMREAD_COLOR)  # BGR；fromfile 可讀非 ASCII 路徑
    if im is None:
        raise IOError(path)
    return im


def write(path, im):
    ok, buf = cv2.imencode(os.path.splitext(path)[1] or ".png", im, [cv2.IMWRITE_JPEG_QUALITY, 100])
    if not ok:
        raise IOError(path)
    buf.tofile(path)


def is_color(im):
    px = im.astype(np.int16)
    # 每個像素 R、G、B 最大減最小，再取平均
    return float((px.max(2) - px.min(2)).mean()) > COLOR_TOL


def to_gray(im):
    """彩色 → 灰階（3 通道相同，與 train IR 一致）。"""
    # 亮度公式（OpenCV 的顏色順序是 BGR）
    g = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    return cv2.merge([g, g, g])


def list_images(d):
    return [os.path.join(d, f) for f in sorted(os.listdir(d)) if f.lower().endswith((".jpg", ".jpeg", ".png"))]


def source_signature(src):
    """轉換方法 + 來源資料夾路徑 + 每張影像的檔名、大小、修改時間；任何一張被換掉或增減都會不同。"""
    lines = ["ir_gray BT.601", os.path.normcase(os.path.abspath(src))]
    for p in list_images(src):
        st = os.stat(p)
        lines.append("{} {} {}".format(os.path.basename(p), st.st_size, st.st_mtime_ns))
    return "\n".join(lines)


def convert(src, dst):
    os.makedirs(dst, exist_ok=True)
    n = 0
    for p in list_images(src):
        out = os.path.join(dst, os.path.basename(p))
        im = read(p)
        if is_color(im):
            write(out, to_gray(im))
            n += 1
        else:
            shutil.copy2(p, out)
    with open(os.path.join(dst, MANIFEST), "w", encoding="utf-8") as f:
        f.write(source_signature(src))
    print("{}：轉換偽彩色 {} 張，其餘原樣複製 → {}".format(src, n, dst))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", required=True, help="熱影像資料夾，例如 data/test/IR/image")
    ap.add_argument("--out", required=True, help="輸出資料夾，例如 outputs/test_IR_gray")
    args = ap.parse_args()
    convert(args.images, args.out)


if __name__ == "__main__":
    main()
