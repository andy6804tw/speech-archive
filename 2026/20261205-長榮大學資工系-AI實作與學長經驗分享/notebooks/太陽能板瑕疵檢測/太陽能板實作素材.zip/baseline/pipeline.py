# -*- coding: utf-8 -*-
"""一鍵跑完整流程。每個步驟都只是呼叫底下的腳本，也可以單獨執行。

    python pipeline.py all                         # IR 轉灰階 → 偵測 → 轉檔 → SFT 資料 → SFT 訓練 → 驗證 → submission
    python pipeline.py dets submit                 # 只跑指定步驟（依給的順序），例如調 --conf 後重出 submission
    python pipeline.py all --reason-model weights/qwen_reason   # 用附的 SFT 權重、不重訓 Qwen（重現官方 baseline）
    python pipeline.py yolo-data train-det --det-batch 4        # 重訓 PRB 偵測器（16 GB 顯卡用 batch 4）

步驟：
  yolo-data   train labelme → YOLO 資料集（tools/labelme2yolo.py）
  train-det   訓練 PRB 偵測器（prb/train.py，參數同原本的 runs/train/pv/opt.yaml）
  ir-norm     test 的偽彩色 IR → 灰階（tools/ir_gray.py，固定的標準亮度公式；train 的 IR 全是灰階）
  detect      PRB 偵測測試集 EO、IR（prb/detect.py；IR 讀 ir-norm 的輸出）
  dets        偵測結果 → outputs/detections.json（reason/yolo2dets.py，含依 train 標註規則的後處理）
  sft-data    train 標註 → SFT 資料（reason/build_sft_data.py）
  train-sft   Qwen SFT（reason/train_sft.py）
  eval        val 上的成因群組準確率（reason/eval_val.py，含純規則 baseline 對照）
  submit      產生 outputs/submission.json（reason/infer_submission.py）
"""
import argparse
import json
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
PRB = os.path.join(ROOT, "prb")
REASON = os.path.join(ROOT, "reason")
DEFAULT_LLM = "Qwen/Qwen2.5-0.5B-Instruct"
DEFAULT_LLM_REVISION = "7ae557604adf67be50417f59c2c2f167def9a775"  # 官方 baseline 訓練時用的版本
DEFAULT_CONF = "solar_panel=0.25,hotspot=0.25,crack=0.25"
STEPS = ["yolo-data", "train-det", "ir-norm", "detect", "dets", "sft-data", "train-sft", "eval", "submit"]
ALL = ["ir-norm", "detect", "dets", "sft-data", "train-sft", "eval", "submit"]
DETECT_MANIFEST = "_detect.json"  # detect 跑完才寫：用了哪個權重、哪個 test 資料夾；dets 據此沿用或檢查
DEFAULT_DET_WEIGHTS = os.path.join(PRB, "runs", "train", "pv", "weights", "best.pt")


def ir_source(ir_gray, test_root):
    """IR 偵測要讀的影像資料夾：ir-norm 的輸出（且確實由目前這批 test IR 影像轉出）。
    沒有可用的輸出時，若測試集有偽彩色影像就停下來（直接用原圖會幾乎偵測不到熱點）；全是灰階才用原圖。"""
    sys.path.insert(0, os.path.join(ROOT, "tools"))
    from ir_gray import MANIFEST, is_color, list_images, read, source_signature
    src = os.path.join(test_root, "IR", "image")
    manifest = os.path.join(ir_gray, MANIFEST)  # 由 tools/ir_gray.py 寫入
    if os.path.exists(manifest):
        with open(manifest, encoding="utf-8") as f:
            if f.read() == source_signature(src):
                return ir_gray
        why = "{} 不是由目前的 {} 轉出的（資料夾搬過、改名或影像換過）".format(ir_gray, src)
    else:
        why = "找不到 ir-norm 的輸出 {}".format(ir_gray)
    if any(is_color(read(p)) for p in list_images(src)):
        sys.exit(why + "。\n測試集有偽彩色熱影像，請先跑 ir-norm 再偵測，例如：python pipeline.py ir-norm detect dets submit"
                 "（其他參數照原本的加上）")
    print(why + "；測試集的熱影像都是灰階，直接用原圖")
    return src


def run(cmd, cwd=ROOT):
    print("\n$ " + " ".join('"{}"'.format(c) if " " in c else c for c in cmd), flush=True)
    # 子程序一律用 UTF-8：輸出導到檔案時中文不會變亂碼，讀寫含中文路徑的設定檔也不會出錯
    subprocess.run(cmd, cwd=cwd, check=True, env=dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1"))


def find_path(p):
    """相對路徑先照目前資料夾找；找不到再照專案根目錄找（從別的資料夾執行時也能用 weights/qwen_reason 這種寫法）。"""
    if not os.path.isabs(p) and not os.path.exists(p) and os.path.exists(os.path.join(ROOT, p)):
        return os.path.join(ROOT, p)
    return os.path.abspath(p)


def count_lines(d):
    if not os.path.isdir(d):
        return 0
    n = 0
    for f in os.listdir(d):
        if f.endswith(".txt"):
            with open(os.path.join(d, f), encoding="utf-8") as fh:
                n += sum(1 for line in fh if line.strip())
    return n


def check_model(llm_final):
    """eval/submit 前：確認成因模型存在，並印出用的是哪一個（試跑模型要提醒）。"""
    if not os.path.isdir(llm_final):
        sys.exit("找不到成因模型 {}。還沒自己訓練 Qwen（train-sft）的話，請在指令後面加 "
                 "--reason-model weights/qwen_reason 改用附的權重。".format(llm_final))
    print("成因模型：", llm_final)
    info = os.path.join(llm_final, "train_args.json")  # reason/train_sft.py 寫入
    if os.path.exists(info):
        with open(info, encoding="utf-8") as f:
            ta = json.load(f)
        if ta.get("epochs", 1) < 1:
            print("注意：這個成因模型只訓練了 {} 個 epoch（試跑用）。正式提交請用完整訓練的模型，"
                  "或加 --reason-model weights/qwen_reason 改用附的權重。".format(ta["epochs"]))


def main():
    for stream in (sys.stdout, sys.stderr):
        if not stream.isatty() and hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")  # 輸出導到檔案時，和子程序一樣用 UTF-8
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("steps", nargs="+", choices=STEPS + ["all"])
    ap.add_argument("--train-root", default=os.path.join(ROOT, "data", "train"))
    ap.add_argument("--test-root", default=os.path.join(ROOT, "data", "test"))
    ap.add_argument("--work", default=os.path.join(ROOT, "outputs"))
    ap.add_argument("--device", default="0", help="cuda 編號或 cpu")
    # 偵測器
    ap.add_argument("--det-weights", default=None,
                    help="偵測器權重，預設 prb/runs/train/pv/weights/best.pt；換成自己訓練的權重時要從 detect 重跑，"
                         "之後只跑 dets 時會自動沿用 detect 當時用的權重")
    ap.add_argument("--det-img", type=int, default=None, help="偵測輸入大小，預設 1280")
    ap.add_argument("--det-epochs", type=int, default=200)
    ap.add_argument("--det-batch", type=int, default=8, help="16 GB 顯卡請用 4")
    ap.add_argument("--conf", default=None,
                    help="各類別信心門檻，只在 dets 步驟生效；預設 " + DEFAULT_CONF +
                         "（評分沒有信心分數，所有框都進 Precision 分母）")
    # SFT
    ap.add_argument("--llm", default=DEFAULT_LLM)
    ap.add_argument("--llm-revision", default=None,
                    help="--llm 在 Hugging Face 上的版本；預設模型自動固定為 " + DEFAULT_LLM_REVISION[:12])
    ap.add_argument("--reason-model", default=None,
                    help="已經 SFT 好的 Qwen 資料夾（例如 weights/qwen_reason）：eval/submit 直接用它，train-sft 略過")
    ap.add_argument("--val-ratio", type=float, default=0.15, help="設 0 = 全部 train 拿去訓練（最終版）")
    ap.add_argument("--epochs", type=float, default=4)
    ap.add_argument("--lr", type=float, default=None, help="預設：全參數 2e-5、LoRA 2e-4")
    ap.add_argument("--bs", type=int, default=16)
    ap.add_argument("--lora", action="store_true")
    ap.add_argument("--precision", choices=["auto", "bf16", "fp16", "fp32"], default="auto",
                    help="SFT 精度；auto = A100/30/40/50 系列用 bf16、V100 用 fp16")
    ap.add_argument("--mode", choices=["generate", "snap", "rank"], default="snap")
    args = ap.parse_args()
    # 偵測步驟在 prb/ 底下執行，相對路徑一律先轉成絕對路徑，避免指到 prb/ 裡面
    det_weights_given, det_img_given = args.det_weights is not None, args.det_img is not None
    if not det_weights_given:
        args.det_weights = DEFAULT_DET_WEIGHTS
    if not det_img_given:
        args.det_img = 1280
    for k in ("train_root", "test_root", "det_weights"):
        setattr(args, k, find_path(getattr(args, k)))

    steps = [s for x in args.steps for s in (ALL if x == "all" else [x])]
    if args.conf is not None and "dets" not in steps:
        print("注意：--conf 只在 dets 步驟生效；這次沒有跑 dets，門檻不會改變（例如改用 python pipeline.py dets submit --conf ...）")
    conf = args.conf if args.conf is not None else DEFAULT_CONF
    if "dets" in steps:
        sys.path.insert(0, REASON)
        from yolo2dets import parse_conf
        parse_conf(conf)  # 格式不對、類別打錯就在一開始停下來說明
    py = sys.executable
    w = os.path.abspath(args.work)
    os.makedirs(w, exist_ok=True)
    yolo_ds = os.path.join(w, "yolo_ds")
    det_dir = os.path.join(w, "detect")
    ir_gray = os.path.join(w, "test_IR_gray")
    dets = os.path.join(w, "detections.json")
    sft = os.path.join(w, "sft_data")
    llm_out = os.path.join(w, "qwen_reason")
    llm_final = find_path(args.reason_model) if args.reason_model else os.path.join(llm_out, "final")
    llm_rev = args.llm_revision or (DEFAULT_LLM_REVISION if args.llm == DEFAULT_LLM else None)

    for step in steps:
        print("\n" + "=" * 20 + " " + step + " " + "=" * 20, flush=True)
        if step == "yolo-data":
            run([py, os.path.join(ROOT, "tools", "labelme2yolo.py"), "--train-root", args.train_root,
                 "--out", yolo_ds])
        elif step == "train-det":
            run([py, "train.py", "--weights", "yolo7.pt",
                 "--cfg", "cfg/training/PRB_Series/PRB-FPN-CSP.yaml",
                 "--data", os.path.join(yolo_ds, "pv.yaml"), "--hyp", "data/hyp.scratch.p5.yaml",
                 "--epochs", str(args.det_epochs), "--batch-size", str(args.det_batch),
                 "--img-size", str(args.det_img), str(args.det_img), "--adam", "--workers", "2",
                 "--device", args.device, "--project", os.path.join(w, "det_train"), "--name", "pv",
                 "--exist-ok"], cwd=PRB)
            print("新權重在 {}；要用它的話，從 detect 重跑並加 --det-weights 指向它".format(
                os.path.join(w, "det_train", "pv", "weights", "best.pt")))
        elif step == "ir-norm":
            src = os.path.join(args.test_root, "IR", "image")
            shutil.rmtree(ir_gray, ignore_errors=True)
            run([py, os.path.join(ROOT, "tools", "ir_gray.py"), "--images", src, "--out", ir_gray])
        elif step == "detect":
            srcs = {"EO": os.path.join(args.test_root, "EO", "image"), "IR": ir_source(ir_gray, args.test_root)}
            shutil.rmtree(det_dir, ignore_errors=True)
            for mod in ("EO", "IR"):
                # detect.py 以附加模式寫 txt，重跑前必須清掉舊結果，否則框會重複
                out_dir = os.path.join(det_dir, "test_" + mod)
                if os.path.exists(out_dir):
                    sys.exit("無法清除舊的偵測結果 {}（檔案可能被其他程式開著），請關掉後再跑".format(out_dir))
                run([py, "detect.py", "--weights", args.det_weights,
                     "--source", srcs[mod],
                     "--img-size", str(args.det_img), "--conf-thres", "0.05", "--iou-thres", "0.45",
                     "--save-txt", "--save-conf", "--nosave", "--no-trace", "--device", args.device,
                     "--project", det_dir, "--name", "test_" + mod, "--exist-ok"], cwd=PRB)
            n = {mod: count_lines(os.path.join(det_dir, "test_" + mod, "labels")) for mod in ("EO", "IR")}
            print("偵測候選框（信心 0.05 以上）：EO {} 個、IR {} 個".format(n["EO"], n["IR"]))
            if n["EO"] + n["IR"] == 0:
                sys.exit("detect 一個框都沒有偵測到。請確認 --det-weights 與 --test-root 是否正確；只訓練很少 epoch 的試跑偵測器"
                         "也可能還偵測不到任何框；如果顯示卡較舊，也可能是半精度（fp16）運算出錯，可以加 --device cpu 試試（會很慢）。")
            for mod in ("EO", "IR"):
                if n[mod] == 0:
                    print("注意：{} 一個框都沒有偵測到，請確認這是預期的結果".format(mod))
            with open(os.path.join(det_dir, DETECT_MANIFEST), "w", encoding="utf-8") as f:
                json.dump({"det_weights": args.det_weights, "test_root": args.test_root,
                           "det_img": args.det_img}, f, ensure_ascii=False, indent=1)
        elif step == "dets":
            mf = os.path.join(det_dir, DETECT_MANIFEST)
            if not os.path.exists(mf):
                sys.exit("找不到 {}：detect 沒有跑完，或是舊版程式留下的輸出。請重跑 detect，例如："
                         "python pipeline.py detect dets submit（其他參數照原本的加上）".format(mf))
            with open(mf, encoding="utf-8") as f:
                used = json.load(f)
            same = lambda a, b: os.path.normcase(str(a)) == os.path.normcase(str(b))
            if not same(used["test_root"], args.test_root):
                sys.exit("現在的偵測結果是用測試資料 {} 產生的，和這次的 {} 不同（換了測試資料，或專案、資料夾搬過）。"
                         "請從 ir-norm 重跑：python pipeline.py ir-norm detect dets submit（其他參數照原本的加上）".format(
                             used["test_root"], args.test_root))
            for key, given, flag in (("det_weights", det_weights_given, "--det-weights"), ("det_img", det_img_given, "--det-img")):
                if given and not same(used[key], getattr(args, key)):
                    sys.exit("現在的偵測結果是用 {} {} 產生的，和這次指定的 {} 不同。要改用它，請從 detect 重跑："
                             "python pipeline.py detect dets submit {} {}（其他參數照原本的加上）；"
                             "要沿用現在的偵測結果，拿掉 {} 即可。".format(flag, used[key], getattr(args, key),
                                                               flag, getattr(args, key), flag))
            if not same(used["det_weights"], DEFAULT_DET_WEIGHTS):
                print("沿用 detect 當時的偵測器權重：", used["det_weights"])
            for mod in ("EO", "IR"):
                ld = os.path.join(det_dir, "test_" + mod, "labels")
                if not os.path.isdir(ld):
                    sys.exit("找不到 detect 的輸出 {}。請重跑 detect".format(ld))
            run([py, os.path.join(REASON, "yolo2dets.py"), "--test-root", args.test_root,
                 "--eo-labels", os.path.join(det_dir, "test_EO", "labels"),
                 "--ir-labels", os.path.join(det_dir, "test_IR", "labels"),
                 "--prb-dir", PRB, "--weights", used["det_weights"], "--conf", conf, "--out", dets])
        elif step == "sft-data":
            run([py, os.path.join(REASON, "build_sft_data.py"), "--train-root", args.train_root,
                 "--out", sft, "--val-ratio", str(args.val_ratio)])
        elif step == "train-sft":
            if args.reason_model:
                print("--reason-model {}：不重訓，略過".format(llm_final))
                continue
            lr = args.lr if args.lr is not None else (2e-4 if args.lora else 2e-5)
            cmd = [py, os.path.join(REASON, "train_sft.py"), "--data", sft, "--model", args.llm,
                   "--out", llm_out, "--epochs", str(args.epochs), "--lr", str(lr), "--bs", str(args.bs),
                   "--precision", args.precision]
            run(cmd + (["--revision", llm_rev] if llm_rev else []) + (["--lora"] if args.lora else []))
        elif step == "eval":
            check_model(llm_final)
            val = os.path.join(sft, "val.jsonl")
            if not os.path.exists(val):
                sys.exit("找不到 {}。請先跑 sft-data（例如 python pipeline.py sft-data eval ...）".format(val))
            if os.path.getsize(val) == 0:
                print("{} 沒有驗證集（上次 sft-data 用了 --val-ratio 0），略過；要恢復請先重跑 "
                      "python pipeline.py sft-data".format(sft))
                continue
            run([py, os.path.join(REASON, "eval_val.py"), "--data", sft, "--baseline", "--show-errors", "0"])
            run([py, os.path.join(REASON, "eval_val.py"), "--data", sft, "--model", llm_final,
                 "--mode", args.mode])
        elif step == "submit":
            check_model(llm_final)
            for p, need in ((dets, "dets"), (os.path.join(sft, "candidates.json"), "sft-data")):
                if not os.path.exists(p):
                    sys.exit("找不到 {}。請先跑 {}".format(p, need))
            run([py, os.path.join(REASON, "infer_submission.py"), "--dets", dets, "--model", llm_final,
                 "--candidates", os.path.join(sft, "candidates.json"), "--mode", args.mode,
                 "--out", os.path.join(w, "submission.json")])
    print("\n完成：" + " → ".join(steps))


if __name__ == "__main__":
    main()
