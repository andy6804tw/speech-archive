"""Classroom comparisons only; official inference and annotations stay unchanged."""
from pathlib import Path
import json

LABELS = {"solar_panel": "正常面板", "crack": "破裂", "hotspot": "熱點"}
COLORS = {"solar_panel": "#2482cf", "crack": "#dc394f", "hotspot": "#ef9a08"}
MIN_OVERLAP = 0.30
AMBIGUITY_MARGIN = 0.05


def box(points, width=1, height=1):
    xs, ys = zip(*points)
    return min(xs) / width, min(ys) / height, max(xs) / width, max(ys) / height


def overlap(a, b):
    intersection = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))
    union = max(0, a[2] - a[0]) * max(0, a[3] - a[1]) + max(0, b[2] - b[0]) * max(0, b[3] - b[1]) - intersection
    return intersection / union if union > 0 else 0.0


def match_objects(predicted, reference):
    """One-to-one maximum-overlap matching within a single image and class.

    Compare enclosing boxes for pairing, but retain original polygons in plots.
    These thresholds organize a teaching display, not official competition scores.
    """
    import numpy as np
    from scipy.optimize import linear_sum_assignment

    matches = []
    for label in ("crack", "hotspot"):
        pi = [i for i, o in enumerate(predicted["objects"]) if o["label"] == label]
        gi = [i for i, o in enumerate(reference["objects"]) if o["label"] == label]
        if not pi or not gi:
            continue
        scores = np.array([[overlap(box(predicted["objects"][p]["points"], predicted["width"], predicted["height"]),
                                   box(reference["objects"][g]["points"], reference["width"], reference["height"]))
                            for g in gi] for p in pi])
        # Prefer more eligible pairs before using overlap to break ties.
        eligible = scores >= MIN_OVERLAP
        weights = np.where(eligible, 1 + scores / (min(len(pi), len(gi)) + 1), 0)
        rr, cc = linear_sum_assignment(-weights)
        for row, column in zip(rr, cc):
            value = float(scores[row, column])
            alternatives = [float(scores[row, j]) for j in range(len(gi)) if j != column and eligible[row, j]]
            alternatives += [float(scores[i, column]) for i in range(len(pi)) if i != row and eligible[i, column]]
            if value >= MIN_OVERLAP and (not alternatives or value - max(alternatives) >= AMBIGUITY_MARGIN):
                matches.append((pi[row], gi[column], value))
    return matches


def build_comparison(detections, reference, submission, case_id):
    rows, panels, counts = [], {}, []
    for mod in ("EO", "IR"):
        key = f"test/{mod}/image/{case_id}.jpg"
        predicted, expected = detections[key], reference[key]
        explained = submission.get(key, [])
        if len(explained) != len(predicted["objects"]) or any(
            a["label"] != b["label"] or a["points"] != b["points"]
            for a, b in zip(predicted["objects"], explained)
        ):
            raise RuntimeError("偵測結果與成因說明不是同一次執行，請重新執行第 5 節，再做對照。")
        matches = match_objects(predicted, expected)
        by_reference = {g: p for p, g, _ in matches}
        used = {p for p, _, _ in matches}
        pred_tags, ref_tags = {}, {}
        for label in ("crack", "hotspot"):
            gi = [g for g, o in enumerate(expected["objects"]) if o["label"] == label]
            gi.sort(key=lambda g: box(expected["objects"][g]["points"])[1::-1])
            for number, g in enumerate(gi, 1):
                tag = f"{LABELS[label]} {number}"
                ref_tags[g] = tag
                p = by_reference.get(g)
                if p is not None:
                    pred_tags[p] = tag
                rows.append({"image": mod, "object": tag, "status": "位置配對" if p is not None else "官方標註未配對",
                             "model_reason": explained[p].get("reason", "尚未產生成因文字") if p is not None else "沒有配對到模型框",
                             "reference_reason": expected["objects"][g].get("reason") or "原始標註未提供成因文字"})
            unmatched = [p for p, o in enumerate(predicted["objects"]) if o["label"] == label and p not in used]
            unmatched.sort(key=lambda p: box(predicted["objects"][p]["points"])[1::-1])
            for number, p in enumerate(unmatched, 1):
                tag = f"{LABELS[label]} P{number}"
                pred_tags[p] = tag
                rows.append({"image": mod, "object": tag, "status": "模型框未配對",
                             "model_reason": explained[p].get("reason", "尚未產生成因文字"),
                             "reference_reason": "沒有可靠配對的官方標註"})
        panels[mod] = {"predicted": pred_tags, "reference": ref_tags}
        for label, name in LABELS.items():
            counts.append([mod, name, sum(o["label"] == label for o in predicted["objects"]),
                           sum(o["label"] == label for o in expected["objects"])])
    return {"rows": rows, "panels": panels, "counts": counts}


def render_comparison(root, case_id, detections, reference, comparison):
    from PIL import Image, ImageDraw, ImageFont

    root = Path(root)
    font = root / "font" / "NotoSansTC-lesson.otf"
    small, title = ImageFont.truetype(str(font), 25), ImageFont.truetype(str(font), 32)
    canvas = Image.new("RGB", (1800, 1370), "white")
    draw = ImageDraw.Draw(canvas)
    draw.rectangle((0, 0, 899, 65), fill="#edf5ff")
    draw.rectangle((900, 0, 1799, 65), fill="#fff6df")
    draw.text((30, 12), "模型預測｜矩形框", font=title, fill="#183b5b")
    draw.text((930, 12), "官方標註｜原始輪廓", font=title, fill="#183b5b")
    draw.line((900, 0, 900, 1310), fill="#d3dce5", width=2)
    for row, mod in enumerate(("EO", "IR")):
        original = Image.open(root / "cases" / case_id / f"{mod}.jpg").convert("RGB")
        original.thumbnail((860, 520))
        caption = "可見光 EO" if mod == "EO" else "熱影像 IR"
        for column, entries in enumerate((detections, reference)):
            left, top = column * 900, 65 + row * 620
            draw.text((left + 25, top + 13), f"{case_id}  {caption}", font=title, fill="#183b5b")
            x, y = left + (900 - original.width) // 2, top + 68 + (520 - original.height) // 2
            canvas.paste(original, (x, y))
            entry = entries[f"test/{mod}/image/{case_id}.jpg"]
            sx, sy = original.width / entry["width"], original.height / entry["height"]
            kind = "predicted" if column == 0 else "reference"
            tags = comparison["panels"][mod][kind]
            positions = []
            for index, obj in sorted(enumerate(entry["objects"]), key=lambda pair: pair[1]["label"] != "solar_panel"):
                label = obj["label"]
                points = [(x + float(px) * sx, y + float(py) * sy) for px, py in obj["points"]]
                color, width = COLORS[label], 2 if label == "solar_panel" else 5
                bounds = box(points)
                if column == 1 and len(points) > 2:
                    draw.line(points + [points[0]], fill=color, width=width)
                else:
                    draw.rectangle(bounds, outline=color, width=width)
                if index not in tags:
                    continue
                text = tags[index] + (f"  {obj['conf']:.2f}" if column == 0 and "conf" in obj else "")
                tw = int(draw.textlength(text, font=small)) + 12
                th = 39
                tx = min(max(left + 8, bounds[0]), left + 892 - tw)
                ty = max(top + 60, bounds[1] - th)
                while any(tx < b[2] and tx + tw > b[0] and ty < b[3] and ty + th > b[1] for b in positions) and ty + 2 * th < top + 603:
                    ty += th + 2
                positions.append((tx, ty, tx + tw, ty + th))
                draw.rectangle(positions[-1], fill=color)
                draw.text((tx + 6, ty + 2), text, font=small, fill="#183b5b" if label == "hotspot" else "white")
        if row == 0:
            draw.line((20, 685, 1780, 685), fill="#d3dce5", width=2)
    draw.text((25, 1320), "藍框：正常面板　紅框：破裂　橘框：熱點　｜　異常編號對照下方成因表；P 表示模型框未配對", font=small, fill="#183b5b")
    path = root / "results" / case_id / "comparison.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(path)
    return str(path)


def compare(root, case_id):
    root = Path(root)
    area = root / "results" / case_id / "run"
    if not (area / "submission.json").is_file():
        raise RuntimeError("請先完成第 3 節物件偵測與第 5 節成因說明，再執行對照。")
    detections = json.loads((area / "detections.json").read_text(encoding="utf-8"))
    reference = json.loads((root / "reference.json").read_text(encoding="utf-8"))
    submission = json.loads((area / "submission.json").read_text(encoding="utf-8"))
    value = build_comparison(detections, reference, submission, case_id)
    image = render_comparison(root, case_id, detections, reference, value)
    result = {"image": image, "rows": value["rows"], "counts": value["counts"]}
    (area.parent / "comparison.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result
