"""Isolated inference-environment tasks for the student notebook."""
from pathlib import Path
import argparse
import json
import platform
import sys


def environment():
    import torch
    import torchvision
    from torchvision.ops import nms
    info = {"python": platform.python_version(), "torch": torch.__version__,
            "torchvision": torchvision.__version__, "cuda": False, "device": "CPU"}
    nms(torch.tensor([[0., 0., 1., 1.]]), torch.tensor([.9]), .5)
    if torch.cuda.is_available():
        try:
            nms(torch.tensor([[0., 0., 1., 1.]], device="cuda"), torch.tensor([.9], device="cuda"), .5)
            assert (torch.ones(1, device="cuda") + 1).item() == 2
            info.update(cuda=True, device=torch.cuda.get_device_name(0))
        except Exception as error:
            info["gpu_error"] = str(error).splitlines()[0]
    return info


def prompts(root, case_id):
    sys.path.insert(0, str(root / "baseline" / "reason"))
    from common import ANOMALY, bbox, describe, mod_of, paired_key
    dets = json.loads((root / "results" / case_id / "run" / "detections.json").read_text(encoding="utf-8"))
    objects = {k: [dict(o, box=bbox(o["points"])) for o in entry["objects"]] for k, entry in dets.items()}
    jobs = []
    for key, objs in objects.items():
        paired = paired_key(key)
        entry, other = dets[key], dets.get(paired)
        for index, obj in enumerate(objs):
            if obj["label"] in ANOMALY:
                prompt = describe(obj, objs, entry["width"], entry["height"], mod_of(key), objects.get(paired),
                                  other["width"] if other else None, other["height"] if other else None)
                jobs.append({"key": key, "index": index, "label": obj["label"], "prompt": prompt})
    return jobs


def render(root, case_id, kind):
    from PIL import Image, ImageDraw, ImageFont
    colors = {"solar_panel": "#2482cf", "crack": "#dc394f", "hotspot": "#ef9a08"}
    labels = {"solar_panel": "正常面板", "crack": "破裂", "hotspot": "熱點"}
    font = root / "font" / "NotoSansTC-lesson.otf"
    small = ImageFont.truetype(str(font), 19)
    title = ImageFont.truetype(str(font), 27)
    canvas = Image.new("RGB", (1600, 730), "#ffffff")
    draw = ImageDraw.Draw(canvas)
    entries = None
    if kind == "detected":
        entries = json.loads((root / "results" / case_id / "run" / "detections.json").read_text(encoding="utf-8"))
    elif kind == "reference":
        entries = json.loads((root / "reference.json").read_text(encoding="utf-8"))
    for column, mod in enumerate(("EO", "IR")):
        image = Image.open(root / "cases" / case_id / f"{mod}.jpg").convert("RGB")
        image.thumbnail((770, 615))
        x, y = column * 800 + (800 - image.width) // 2, 70 + (615 - image.height) // 2
        canvas.paste(image, (x, y))
        caption = "可見光 EO" if mod == "EO" else "熱影像 IR"
        draw.text((column * 800 + 25, 17), f"{case_id}  {caption}", font=title, fill="#183b5b")
        if entries:
            e = entries[f"test/{mod}/image/{case_id}.jpg"]
            sx, sy = image.width / e["width"], image.height / e["height"]
            objects = sorted(e["objects"], key=lambda o: o["label"] != "solar_panel")
            for obj in objects:
                label = obj["label"]
                points = [(x + float(px) * sx, y + float(py) * sy) for px, py in obj["points"]]
                color = colors[label]
                width = 2 if label == "solar_panel" else 4
                if kind == "reference" and len(points) > 2:
                    draw.line(points + [points[0]], fill=color, width=width)
                else:
                    xs, ys = zip(*points)
                    draw.rectangle((min(xs), min(ys), max(xs), max(ys)), outline=color, width=width)
                if label != "solar_panel":
                    text = labels[label] + (f" {obj['conf']:.2f}" if "conf" in obj else "")
                    text_box = draw.textbbox((0, 0), text, font=small)
                    tw, th = text_box[2] + 8, text_box[3] + 7
                    tx = min(max(column * 800 + 10, min(p[0] for p in points)), (column + 1) * 800 - tw - 10)
                    ty = max(63, min(p[1] for p in points) - th)
                    draw.rectangle((tx, ty, tx + tw, ty + th), fill=color)
                    draw.text((tx + 4, ty + 1), text, font=small, fill="white")
    if entries:
        draw.text((30, 694), "藍框：正常面板     紅框：破裂     橘框：熱點", font=small, fill="#183b5b")
        draw.text((1300, 694), "人工標註" if kind == "reference" else "模型偵測", font=small, fill="#516474")
    path = root / "results" / case_id / f"{kind}.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(path)
    return {"image": str(path)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["environment", "prompts", "detections", "original", "detected", "reference", "comparison"])
    parser.add_argument("--root", type=Path)
    parser.add_argument("--case")
    args = parser.parse_args()
    if args.action == "environment":
        value = environment()
    elif args.action == "prompts":
        value = prompts(args.root, args.case)
    elif args.action == "comparison":
        from comparison import compare
        value = compare(args.root, args.case)
    elif args.action == "detections":
        value = json.loads((args.root / "results" / args.case / "run" / "detections.json").read_text(encoding="utf-8"))
    else:
        value = render(args.root, args.case, args.action)
    print(json.dumps(value, ensure_ascii=False))


if __name__ == "__main__":
    main()
